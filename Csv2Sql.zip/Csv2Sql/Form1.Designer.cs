﻿namespace Decrypt
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txtSqlConnection = new System.Windows.Forms.TextBox();
            this.txtCsvFile = new System.Windows.Forms.TextBox();
            this.txtTargetTableNOTUSED = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblFileName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.chkDropTable = new System.Windows.Forms.CheckBox();
            this.chkIncludeEmpty = new System.Windows.Forms.CheckBox();
            this.cmbEncoding = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbSourceType = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.chkCreateQueries = new System.Windows.Forms.CheckBox();
            this.chkTblPrefix = new System.Windows.Forms.CheckBox();
            this.superGridControl1 = new DevComponents.DotNetBar.SuperGrid.SuperGridControl();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(133, 222);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(125, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Go";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtSqlConnection
            // 
            this.txtSqlConnection.Location = new System.Drawing.Point(133, 29);
            this.txtSqlConnection.Name = "txtSqlConnection";
            this.txtSqlConnection.Size = new System.Drawing.Size(380, 20);
            this.txtSqlConnection.TabIndex = 1;
            this.txtSqlConnection.Text = "Driver={SQL Server};Server=(local);Trusted_Connection=Yes;Database=CSV;";
            // 
            // txtCsvFile
            // 
            this.txtCsvFile.Location = new System.Drawing.Point(133, 77);
            this.txtCsvFile.Name = "txtCsvFile";
            this.txtCsvFile.Size = new System.Drawing.Size(332, 20);
            this.txtCsvFile.TabIndex = 2;
            // 
            // txtTargetTableNOTUSED
            // 
            this.txtTargetTableNOTUSED.Location = new System.Drawing.Point(133, 103);
            this.txtTargetTableNOTUSED.Name = "txtTargetTableNOTUSED";
            this.txtTargetTableNOTUSED.Size = new System.Drawing.Size(332, 20);
            this.txtTargetTableNOTUSED.TabIndex = 3;
            this.txtTargetTableNOTUSED.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "SQL Connection String";
            // 
            // lblFileName
            // 
            this.lblFileName.AutoSize = true;
            this.lblFileName.Location = new System.Drawing.Point(12, 84);
            this.lblFileName.Name = "lblFileName";
            this.lblFileName.Size = new System.Drawing.Size(47, 13);
            this.lblFileName.TabIndex = 5;
            this.lblFileName.Text = "CSV File";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Target Table";
            // 
            // chkDropTable
            // 
            this.chkDropTable.AutoSize = true;
            this.chkDropTable.Checked = true;
            this.chkDropTable.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDropTable.Location = new System.Drawing.Point(133, 162);
            this.chkDropTable.Name = "chkDropTable";
            this.chkDropTable.Size = new System.Drawing.Size(104, 17);
            this.chkDropTable.TabIndex = 7;
            this.chkDropTable.Text = "Drop Table first?";
            this.chkDropTable.UseVisualStyleBackColor = true;
            // 
            // chkIncludeEmpty
            // 
            this.chkIncludeEmpty.AutoSize = true;
            this.chkIncludeEmpty.Checked = true;
            this.chkIncludeEmpty.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIncludeEmpty.Location = new System.Drawing.Point(271, 162);
            this.chkIncludeEmpty.Name = "chkIncludeEmpty";
            this.chkIncludeEmpty.Size = new System.Drawing.Size(142, 17);
            this.chkIncludeEmpty.TabIndex = 8;
            this.chkIncludeEmpty.Text = "Include Empty Columns?";
            this.chkIncludeEmpty.UseVisualStyleBackColor = true;
            // 
            // cmbEncoding
            // 
            this.cmbEncoding.FormattingEnabled = true;
            this.cmbEncoding.Items.AddRange(new object[] {
            "ANSI",
            "Unicode",
            "UTF8"});
            this.cmbEncoding.Location = new System.Drawing.Point(133, 129);
            this.cmbEncoding.Name = "cmbEncoding";
            this.cmbEncoding.Size = new System.Drawing.Size(121, 21);
            this.cmbEncoding.TabIndex = 9;
            this.cmbEncoding.Text = "ANSI";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "File Format";
            // 
            // cmbSourceType
            // 
            this.cmbSourceType.FormattingEnabled = true;
            this.cmbSourceType.Items.AddRange(new object[] {
            "CSV File",
            "Folder"});
            this.cmbSourceType.Location = new System.Drawing.Point(133, 55);
            this.cmbSourceType.Name = "cmbSourceType";
            this.cmbSourceType.Size = new System.Drawing.Size(121, 21);
            this.cmbSourceType.TabIndex = 11;
            this.cmbSourceType.Text = "CSV File";
            this.cmbSourceType.SelectedIndexChanged += new System.EventHandler(this.cmbSourceType_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 58);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Source Type";
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(472, 77);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(41, 23);
            this.btnBrowse.TabIndex = 13;
            this.btnBrowse.Text = "...";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(556, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Results";
            // 
            // chkCreateQueries
            // 
            this.chkCreateQueries.AutoSize = true;
            this.chkCreateQueries.Checked = true;
            this.chkCreateQueries.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCreateQueries.Location = new System.Drawing.Point(133, 185);
            this.chkCreateQueries.Name = "chkCreateQueries";
            this.chkCreateQueries.Size = new System.Drawing.Size(124, 17);
            this.chkCreateQueries.TabIndex = 16;
            this.chkCreateQueries.Text = "Create SQL queries?";
            this.chkCreateQueries.UseVisualStyleBackColor = true;
            // 
            // chkTblPrefix
            // 
            this.chkTblPrefix.AutoSize = true;
            this.chkTblPrefix.Checked = true;
            this.chkTblPrefix.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkTblPrefix.Location = new System.Drawing.Point(271, 185);
            this.chkTblPrefix.Name = "chkTblPrefix";
            this.chkTblPrefix.Size = new System.Drawing.Size(178, 17);
            this.chkTblPrefix.TabIndex = 17;
            this.chkTblPrefix.Text = "Add \"tbl\" prefix for table names?";
            this.chkTblPrefix.UseVisualStyleBackColor = true;
            // 
            // superGridControl1
            // 
            this.superGridControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.superGridControl1.BackColor = System.Drawing.Color.White;
            this.superGridControl1.FilterExprColors.SysFunction = System.Drawing.Color.DarkRed;
            this.superGridControl1.ForeColor = System.Drawing.Color.Black;
            this.superGridControl1.LicenseKey = "F962CEC7-CD8F-4911-A9E9-CAB39962FC1F";
            this.superGridControl1.Location = new System.Drawing.Point(559, 25);
            this.superGridControl1.Name = "superGridControl1";
            this.superGridControl1.Size = new System.Drawing.Size(280, 236);
            this.superGridControl1.TabIndex = 18;
            this.superGridControl1.Text = "superGridControl1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(851, 273);
            this.Controls.Add(this.superGridControl1);
            this.Controls.Add(this.chkTblPrefix);
            this.Controls.Add(this.chkCreateQueries);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmbSourceType);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbEncoding);
            this.Controls.Add(this.chkIncludeEmpty);
            this.Controls.Add(this.chkDropTable);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblFileName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtTargetTableNOTUSED);
            this.Controls.Add(this.txtCsvFile);
            this.Controls.Add(this.txtSqlConnection);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "CSV2SQL";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtSqlConnection;
        private System.Windows.Forms.TextBox txtCsvFile;
        private System.Windows.Forms.TextBox txtTargetTableNOTUSED;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblFileName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkDropTable;
        private System.Windows.Forms.CheckBox chkIncludeEmpty;
        private System.Windows.Forms.ComboBox cmbEncoding;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbSourceType;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkCreateQueries;
        private System.Windows.Forms.CheckBox chkTblPrefix;
        private DevComponents.DotNetBar.SuperGrid.SuperGridControl superGridControl1;
    }
}


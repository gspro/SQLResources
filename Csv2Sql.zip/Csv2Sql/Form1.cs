﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LumenWorks.Framework.IO.Csv;
using System.IO;
using System.Data.Odbc;

namespace Decrypt
{
    public partial class Form1 : Form
    {
        private Encoding TextEncoding = Encoding.GetEncoding(1252);
        private FolderBrowserDialog dlgFolder1 = new FolderBrowserDialog();
        private OpenFileDialog dlgFile1 = new OpenFileDialog();
        private BackgroundWorker ImportWorker = new BackgroundWorker();

        List<CSVFileStatus> FileStatus = new List<CSVFileStatus>();
         
        //public Encoding TextEncoding = Encoding.Unicode;
        public Form1()
        {
            InitializeComponent();

            if (!string.IsNullOrEmpty(Properties.Settings.Default.LastConnectionString)) this.txtSqlConnection.Text = Properties.Settings.Default.LastConnectionString;

            ImportWorker.DoWork += Importer_DoWork;
            ImportWorker.RunWorkerCompleted += Importer_Completed;
            ImportWorker.ProgressChanged += Importer_Progress;
            ImportWorker.WorkerReportsProgress = true;
          }

        private void Importer_Progress(object sender, ProgressChangedEventArgs e)
        {
            //superGridControl1.Refresh();
            //throw new NotImplementedException();
        }

        private void Importer_Completed(object sender, RunWorkerCompletedEventArgs e)
        {
            MessageBox.Show("Done!");
            button1.Enabled = true;
            button1.Text = "GO";
   
        }

        private void Importer_DoWork(object sender, DoWorkEventArgs e)
        {
            ImportDataNow();
        }
        private string[] GetColumnHeaders(string filename)
        {
            try
            {
                using (CsvReader csv = new CsvReader(new StreamReader(filename, TextEncoding), true, ','))
                {
                    return csv.GetFieldHeaders();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("GetColumnHeaders Unable to open specified file: " + filename + ": " + ex.ToString());
            }
        }

        string MakeTableAccess(string filename, string tablename, bool IncludeEmpty)
        {
            string results = "CREATE TABLE [" + tablename + "] \n ( \n";
            Dictionary<string, int> cols = CSVGetMaxLengths(filename);
            foreach (string col in cols.Keys)
            {
                int maxlen = cols[col];
                if (maxlen > 500)
                {
                    results += col.Replace(" ", "") + " LONGTEXT, \n";
                }
                else if (maxlen > 0 || IncludeEmpty)
                {
                    if (maxlen == 0) maxlen = 1;
                    results += col.Replace(" ", "") + " VARCHAR(" + maxlen + "), \n";
                }
            }

            results += "PROCESSEDON DATETIME \n";
            results += ")";

            return results;
        }
        string MakeTableSqlServer(string filename, string tablename, bool IncludeEmpty)
        {
            string results = "CREATE TABLE [" + tablename + "] \n ( \n";
            Dictionary<string, int> cols = CSVGetMaxLengths(filename);
            foreach (string col in cols.Keys)
            {
                int maxlen = cols[col];
                if (maxlen > 500)
                {
                    results += "[" + col.Replace(" ", "").Replace("-", "").Replace("/", "") + "] NVARCHAR(MAX), \n";
                }
                else if (maxlen > 0 || IncludeEmpty)
                {
                    if (maxlen == 0) maxlen = 1;
                    results += "[" + col.Replace(" ", "").Replace("-", "").Replace("/", "") + "] NVARCHAR(" + maxlen + "), \n";
                }
            }

            results += "PROCESSEDON DATETIME \n";
            results += ")";

            return results;
        }
        private Dictionary<string, int> CSVGetMaxLengths(string filename)
        {
            Dictionary<string, int> results = new Dictionary<string, int>();

            try
            {
                using (CsvReader csv = new CsvReader(new StreamReader(filename, TextEncoding), true, ','))
                {
                    string[] headers = csv.GetFieldHeaders();
                    while (csv.ReadNextRecord())
                    {
                        foreach (string header in headers)
                        {
                            if (csv[header] != "NULL")
                            {
                                int MaxLen = csv[header].Length;
                                if (!results.ContainsKey(header)) results.Add(header, MaxLen);
                                else if (MaxLen > results[header]) results[header] = MaxLen;
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Unable to open specified file: " + filename + ": " + ex.ToString());
            }


            return results;
        }

        private int CSVRowCount(string filename)
        {
            try
            {
                int result = -1;
                using (CsvReader csv = new CsvReader(new StreamReader(filename, TextEncoding), true, ','))
                {
                    result =  csv.Count();
                }
                

                return result;
                
            }
            catch (Exception ex)
            {
                return -1;
            }
        }

        private void CSVWriteInsert(CSVFileStatus stat, DBUtil.DBUtilODBC db)
        {
            try
            {
                using (CsvReader csv = new CsvReader(new StreamReader(stat.FullPath, TextEncoding), true, ','))
                {                    
                    string[] headers = csv.GetFieldHeaders();

                    OdbcConnection cn = new OdbcConnection();
                    cn.ConnectionString = db.GetConnString();
                    cn.Open();
                    int i = 0;

                    while (csv.ReadNextRecord())
                    {
                        i++;
                        Dictionary<string, string> values = new Dictionary<string, string>();
                        foreach (string header in headers)
                        {
                            if (!values.ContainsKey(header) && csv[header] != "" && csv[header] != "NULL")
                            {
                                values.Add(header.Replace(" ", "").Replace("-", "").Replace("/", ""), csv[header]);                                
                            }
                        }
                        try
                        {
                            
                            string sql = db.Inserter(stat.FileName, values);
                            sql = sql.Replace('\x00', ' ');
                            OdbcCommand cmd = new OdbcCommand();
                            cmd.Connection = cn;
                            cmd.CommandText = sql;
                            int result = cmd.ExecuteNonQuery();
                            cmd.Dispose();
                            
                            stat.Inserts++;
                            ImportWorker.ReportProgress(stat.Inserts / stat.Rows);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error inserting record into table " + stat.FileName + ":" + ex.ToString());
                            cn.Close();
                            cn.Dispose();

                            return;                        
                        }
                    }
                    csv.Dispose(); // close the stream
                    cn.Close();
                    cn.Dispose();
                    
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to open SQLify file: " + stat.FileName + ": " + ex.ToString());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button1.Text = "(running)";
            if (cmbEncoding.Text == "Unicode")
            {
                TextEncoding = Encoding.Unicode;
            }
            else if (cmbEncoding.Text == "ANSI")
            {
                TextEncoding = Encoding.GetEncoding(1252); //ANSI
            }
            else if (cmbEncoding.Text == "UTF8")
            {
                TextEncoding = Encoding.UTF8;
            }
            ImportWorker.RunWorkerAsync();


        }
        private void ImportDataNow()
        {

            //string connstring = "Driver={Microsoft Access Driver (*.mdb)};Dbq=C:\\Stage\\db1.mdb;Uid=Admin;Pwd=;";
            //string connstring = "Driver={SQL Server};Server=(local);Trusted_Connection=Yes;Database=CSV;";

                foreach(CSVFileStatus stat in this.FileStatus)
                {
                     try
                     {
                         if (stat.Include)
                         {
                             CreateTable(stat);
                         }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error creating table " + stat.FileName + ":" + ex.ToString());
                        }
                }
        }


        private void CreateTable(CSVFileStatus stat)
        {
            stat.Inserts = 0; // reset counter
            string connstring = txtSqlConnection.Text;

            DBUtil.DBUtilODBC db;
            string create = "";

            if (connstring.Contains("Microsoft Access"))
            {
                db = new DBUtil.DBUtilODBC(connstring, DBUtil.DatabaseType.ACCESS);
                create = MakeTableAccess(stat.FullPath, stat.FileName, chkIncludeEmpty.Checked);
            }
            else
            {
                db = new DBUtil.DBUtilODBC(connstring, DBUtil.DatabaseType.MSSQL);
                create = MakeTableSqlServer(stat.FullPath, stat.FileName, chkIncludeEmpty.Checked);
            }


            try
            {
                try
                {
                    if (chkDropTable.Checked) db.ExecSQL("DROP TABLE [" + stat.FileName + "]");
                }
                catch { }

                db.ExecSQL(create);
                CSVWriteInsert(stat, db);
                         }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR in table " + stat.FileName + ": " + ex.ToString());
                //button1.Enabled = true;
                //button1.Text = "GO";
            }

            if (chkCreateQueries.Checked)
            {
                string sql = "select * from [" + stat.FileName + "] where PROCESSEDON is null";
                File.WriteAllText("sql" + stat.FileName + ".sql", sql);
            }


        }

        private void cmbSourceType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cmbSourceType.Text == "Folder")
            {
                txtTargetTableNOTUSED.Text = "";
                txtTargetTableNOTUSED.Enabled = false;
                lblFileName.Text = "Folder";
            }
            else // file
            {
                lblFileName.Text = "CSV File";
                if (txtTargetTableNOTUSED.Text == "") txtTargetTableNOTUSED.Text = Path.GetFileNameWithoutExtension(txtCsvFile.Text);
                txtTargetTableNOTUSED.Enabled = true;
            }
           
        }
        private void GetFileList()
        {
            
            this.FileStatus = new List<CSVFileStatus>();

            if (cmbSourceType.Text == "Folder")
            {
                string[] files = Directory.GetFiles(txtCsvFile.Text);
                foreach (string fn in files)
                {
                    string ext = Path.GetExtension(fn).ToLower();
                    if (ext == ".csv" || ext == ".txt" || ext == "." || ext == "")
                    {
                        string tablename = "";
                        if (chkTblPrefix.Checked) tablename = "tbl";

                        tablename += Path.GetFileNameWithoutExtension(fn);
                        CSVFileStatus stat = new CSVFileStatus();
                        stat.FileName = tablename;
                        stat.Rows = CSVRowCount(fn);
                        stat.Inserts = 0;
                        stat.FullPath = fn;
                        stat.Include = true;
                        FileStatus.Add(stat);
                    }
                }
            }
            else
            {
                string tablename = "";
                if (chkTblPrefix.Checked) tablename = "tbl";

                tablename += Path.GetFileNameWithoutExtension(txtCsvFile.Text);
                CSVFileStatus stat = new CSVFileStatus();
                stat.FileName = tablename;
                stat.Rows = CSVRowCount(txtCsvFile.Text);
                stat.Inserts = 0;
                stat.FullPath = txtCsvFile.Text;
                stat.Include = true;
                FileStatus.Add(stat);
             
            }
            this.superGridControl1.PrimaryGrid.DataSource = FileStatus;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            if (cmbSourceType.Text == "Folder")
            {
                if (dlgFolder1.ShowDialog() == DialogResult.OK)
                {
                    txtCsvFile.Text = dlgFolder1.SelectedPath;
                }
            }
            else
            {
                if (dlgFile1.ShowDialog() == DialogResult.OK)
                {
                    txtCsvFile.Text = dlgFile1.FileName;
                    //if (txtTargetTableNOTUSED.Text == "") txtTargetTableNOTUSED.Text = Path.GetFileNameWithoutExtension(txtCsvFile.Text);
                }
            }
            GetFileList();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.LastConnectionString = this.txtSqlConnection.Text;
            Properties.Settings.Default.Save();
                    
        }
    }

    class CSVFileStatus //: INotifyPropertyChanged
    {
        private int _Inserts;
        public bool Include { get; set; }

        public string FileName { get; set; }

        public int Rows { get; set; }

        public int Inserts {
            get { return _Inserts; }
            set { 
                _Inserts = value; 
            //     NotifyPropertyChanged(); 
            }
        }

        public string FullPath { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

       /* private void NotifyPropertyChanged()
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs("Inserts"));
            }
        }
        * */
    }
}
﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Configuration;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Data.Odbc;
using System.Linq;
using System.Data.SqlServerCe;


namespace DBUtil
{
    public class DatabaseHelper
    {
        protected string DBSTRING = "";
        protected string DBSTRING_Master = "";
        protected SqlConnection sqlConnection = new SqlConnection();
        protected string dbName = "";
        private string _DateTimeString = "yyyy-MM-dd";

        public DatabaseHelper() { }
        public DatabaseHelper(string dbname, string dbConnString)
        {
            this.dbName = dbname;
            this.DBSTRING = dbConnString.Replace("{0}", dbname);
            this.DBSTRING_Master = dbConnString.Replace("{0}", "master");
        }

        public string DateFormatString { get { return this._DateTimeString; } set { this._DateTimeString = value; } }
    
        protected Dictionary<string, Dictionary<string, string>> SchemaCache = new Dictionary<string, Dictionary<string, string>>();
        public string Inserter(string table, Dictionary<string, string> Values)
        {
            Dictionary<string, string> Attributes = CacheGetCurrentAttributes(table);

            string SQL = "INSERT into " + DBUtilODBC.bracketize(table) + " ("; // start a SQL insert statement
            string vals = "(";

            foreach (string field in Values.Keys) // loop through values to build sql
            {
                if (Attributes.ContainsKey(field))
                {
                    SQL += DBUtilODBC.bracketize (field) + ", ";
                    if (Attributes[field] == "datetime" || Attributes[field] == "date")
                    {
                        if (Values[field].ToString() == "") vals += "null, ";
                        else
                        {
                            DateTime dte = DateTime.Parse(Values[field].ToString());
                            vals += "'" + dte.ToString(_DateTimeString) + "', ";
                        }
                    }
                    else if (Attributes[field] == "uniqueidentifier")
                    {
                        if (Values[field] != "" && Values[field] != null)
                        {
                            vals += "'" + SQLClean(Values[field]) + "', ";
                        }
                        else vals += "NULL, ";
                    }
                    else
                    {
                        vals += "'" + SQLClean(Values[field]) + "', ";
                    }
                }
            }
            SQL = SQL.Trim(new char[] { ',', ' ' }) + ")"; // remove extra coma, close the list
            vals = vals.Trim(new char[] { ',', ' ' }) + ")";


            return SQL + " values " + vals; // put it all together as a finished SQL Insert statement
        }
        public string Updater(string table, string PrimaryKey, Dictionary<string, string> Values)
        {
            Dictionary<string, string> Attributes = CacheGetCurrentAttributes(table);

            string SQL = "UPDATE " + DBUtilODBC.bracketize(table) + " set "; // start a SQL insert statement

            foreach (string field in Values.Keys) // loop through values to build sql
            {
                if (Attributes.ContainsKey(field) && field != PrimaryKey)
                {
                    SQL += DBUtilODBC.bracketize (field) +  " = ";
                    if (Attributes[field] == "datetime" || Attributes[field] == "date")
                    {
                        if (Values[field].ToString() == "") { SQL += "null, "; }
                        else
                        {
                            DateTime dte = DateTime.Parse(Values[field].ToString());
                            SQL += "'" + dte.ToString(_DateTimeString) + "', ";
                        }
                    }
                    else
                    {
                        SQL += "'" + SQLClean(Values[field]) + "', ";
                    }
                }
            }
            SQL = SQL.Trim(new char[] { ',', ' ' }); // remove extra coma, close the list
            SQL += " WHERE " + PrimaryKey + " = '" + Values[PrimaryKey] + "'";
            return SQL;
        }
        private List<string> GetColumns(DataColumnCollection cols)
        {
            List<string> results = new List<string>();
            foreach (DataColumn col in cols)
            {
                if (!results.Contains(col.ColumnName)) results.Add(col.ColumnName);
            }
            return results;
        }
        public List<string> DataTableToInserts(string tablename, DataTable table)
        {
            List<string> columns = GetColumns(table.Columns);
            Dictionary<string, string> Attributes = CacheGetCurrentAttributes(tablename);
            
            List<string> results = new List<string>();
            
            foreach (DataRow dr in table.Rows)
            {
                string SQL = "INSERT into " + DBUtilODBC.bracketize(tablename) + " ("; // start a SQL insert statement
                string vals = "(";

                foreach (string field in columns) // loop through values to build sql
                {
                    if (Attributes.ContainsKey(field))
                    {
                        SQL += DBUtilODBC.bracketize(field) + ", ";
                        if (Attributes[field] == "datetime" || Attributes[field] == "date")
                        {
                            if (dr[field].ToString() == "") vals += "null, ";
                            else
                            {
                                DateTime dte = DateTime.Parse(dr[field].ToString());
                                vals += "'" + dte.ToString(_DateTimeString) + "', ";
                            }
                        }
                        else if (Attributes[field] == "uniqueidentifier")
                        {
                            if (dr[field] != "" && dr[field] != null)
                            {
                                vals += "'" + SQLClean(dr[field].ToString()) + "', ";
                            }
                            else vals += "NULL, ";
                        }
                        else
                        {
                            vals += "'" + SQLClean(dr[field].ToString()) + "', ";
                        }
                    }
                }
                SQL = SQL.Trim(new char[] { ',', ' ' }) + ")"; // remove extra coma, close the list
                vals = vals.Trim(new char[] { ',', ' ' }) + ")";
                results.Add(SQL + " values " + vals);
            }

            return results;
        }
        protected Dictionary<string, string> GetCurrentAttributes(string tablename)
        {
            Dictionary<string, string> results = new Dictionary<string, string>();
            using (SqlConnection cn = new SqlConnection(DBSTRING))
            {
                string sql = "";

                SqlCommand cmd = new SqlCommand("SELECT c.name AS column_name, ty.name as column_type FROM sys.tables AS t INNER JOIN sys.columns c ON t.OBJECT_ID = c.OBJECT_ID  INNER JOIN sys.types ty on C.system_type_id=ty.system_type_id where t.name = '" + tablename + "'", cn);
                cn.Open();
                cmd.CommandTimeout = 30 * 60; // 30 minutes
                SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                while (rdr.Read())
                {
                    results.Add(rdr[0].ToString(), rdr[1].ToString());
                }
            }
            return results;

        }
        protected Dictionary<string, string> CacheGetCurrentAttributes(string tablename)
        {
            if (this.SchemaCache.ContainsKey(tablename)) return this.SchemaCache[tablename];
            else
            {
                this.SchemaCache.Add(tablename, GetCurrentAttributes(tablename));
                return this.SchemaCache[tablename];
            }
        }
        public Dictionary<string, string> DataRowToDictionary(DataRow dr, string fields)
        {
            Dictionary<string, string> results = new Dictionary<string, string>();
            string[] arrFields = fields.Split(new char[] { ',' });

            foreach (string fieldname in arrFields)
            {
                string field = fieldname.Trim();
                try
                {
                    if (dr[field] != null)
                    {
                        results.Add(field, dr[field].ToString());
                    }
                }
                catch (Exception ex) { }
            }
            return results;
        }
        public DateTime GetMaxModifiedOn(string tablename, string fieldname = "modifiedon", string where = "1=1")
        {
            try
            {
                string stmt = "select MAX(" + SQLClean(fieldname) + ") as modifiedon from " + SQLClean(tablename) + " where " + where;
                using (SqlConnection cn = new SqlConnection(DBSTRING))
                {
                    SqlCommand cmd = new SqlCommand(stmt, cn);
                    cmd.CommandTimeout = 30 * 60; // 30 minutes
                    cn.Open();
                    SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                    if (rdr.HasRows) while (rdr.Read())
                        {
                            if (rdr[0].ToString() != "") return DateTime.Parse(rdr[0].ToString());
                        }
                }
                return DateTime.MinValue; // if nothing is found
            }
            catch (Exception ex)
            {
                if (ex.ToString().Contains("Invalid column name 'modifiedon'")) return DateTime.MinValue; // if nothing is found 
                else throw ex;
            }
        }
        public Guid GetContactIdByEmail(string email)
        {
            try
            {
                string stmt = "select contactid from contact where emailaddress1='" + SQLClean(email) + "'";
                using (SqlConnection cn = new SqlConnection(DBSTRING))
                {
                    SqlCommand cmd = new SqlCommand(stmt, cn);
                    cn.Open();
                    cmd.CommandTimeout = 30 * 60; // 30 minutes
                    SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                    if (rdr.HasRows) while (rdr.Read())
                        {
                            if (rdr[0].ToString() != "") return new Guid(rdr[0].ToString());
                        }
                }
                return Guid.Empty;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error finding Contact: " + email);
                return Guid.Empty;
            }
        }
        public Guid GetLeadIdByEmail(string email)
        {
            try
            {
                string stmt = "select leadid from lead where emailaddress1='" + SQLClean(email) + "'";
                using (SqlConnection cn = new SqlConnection(DBSTRING))
                {
                    SqlCommand cmd = new SqlCommand(stmt, cn);
                    cn.Open();
                    cmd.CommandTimeout = 30 * 60; // 30 minutes
                    SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                    if (rdr.HasRows) while (rdr.Read())
                        {
                            if (rdr[0].ToString() != "") return new Guid(rdr[0].ToString());
                        }
                }
                return Guid.Empty;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error finding Lead: " + email);
                return Guid.Empty;
            }
        }
        protected string SQLClean(string val)
        {
            if (val == null) return "";
            else return val.Replace("'", "''");
        }
        protected string SQLClean(DateTime val)
        {
            if (val == null) return "";
            else if (val == DateTime.MinValue) return "";
            else return val.ToString();
        }
        protected string GetFormattedDbName(string dbName)
        {
            return "CC2011_" + dbName.Trim(new char[] { '{', '}' }).Replace("-", "");
        }
        protected bool DoesDatabaseExist(string dbName, string connStr)
        {
            bool dbExists = false;
            string sql = "SELECT COUNT(*) FROM sys.databases  with (nolock) WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb') AND name = '" + dbName + "'";

            IDbCommand cmd = CreateCommand(connStr, sql);
            int rowCount = Convert.ToInt32(cmd.ExecuteScalar());

            if (rowCount == 1)
                dbExists = true;

            return dbExists;
        }
        public void CreateDatabase()
        {
            try
            {
                sqlConnection = new SqlConnection(DBSTRING_Master);
                if (!DoesDatabaseExist(dbName, DBSTRING_Master))
                {
                    CreateSQLDatabase(dbName, DBSTRING_Master);
                    sqlConnection.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Database create exception: " + ex.ToString());
            }
        }
        protected void CreateSQLDatabase(string dbName, string connStr)
        {
            Console.WriteLine("Starting to create tables ...");
            StreamReader myFile = new StreamReader("CreateCCubedDatabase2011.sql");
            string sql = myFile.ReadToEnd();
            myFile.Close();
            sql = sql.Replace("~DBName~", dbName);


            string[] commands = sql.Split(new string[] { "GO\r\n", "GO ", "GO\t" }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string c in commands)
            {
                try
                {
                    IDbCommand cmd = CreateCommand(connStr, c);
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.Beep();
                    Console.WriteLine("Error with this statement: " + c);
                }
            }
            Console.WriteLine("Done creating tables....");
        }
        protected IDbCommand CreateCommand(string connectionString, string sqlString)
        {
            IDbCommand cmd = new SqlCommand();
            cmd.Connection = GetOpenConnection(connectionString);
            cmd.CommandText = sqlString;
            cmd.CommandType = CommandType.Text;
            cmd.CommandTimeout = 3600; // in second (60 min)

            return cmd;
        }
        public void RunSql(string Sql)
        {
            IDbCommand cmd = CreateCommand(DBSTRING, Sql);
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();
        }
        public static void AddParameter(IDbCommand pCmd, string pParamNme, DbType pParamType, ParameterDirection pParamDirection, object pParamValue)
        {
            IDbDataParameter param = pCmd.CreateParameter();
            param.ParameterName = pParamNme;
            param.DbType = pParamType;
            param.Direction = pParamDirection;
            param.Value = pParamValue;
            pCmd.Parameters.Add(param);
        }
        protected SqlConnection GetOpenConnection(string connectionString)
        {
            SqlConnection.ClearAllPools();

            if (connectionString == sqlConnection.ConnectionString)
            {
                if (sqlConnection.State != System.Data.ConnectionState.Open)
                {
                    sqlConnection.Open();
                }
            }
            else
            {
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
            }

            return sqlConnection;
        }
    }

    public class DBUtilODBC
    {
        private DatabaseType dbtype;
        private string ConnectionString;
        private string _DateTimeString = "yyyy-MM-dd";
        public string CurrentDateFunction
        {
            get
            {
                if (dbtype == DatabaseType.ORACLE) return "CURRENT_DATE";
                else if (dbtype == DatabaseType.ACCESS) return "NOW()";
                else if (dbtype == DatabaseType.MYSQL) return "NOW()";
                else if (dbtype == DatabaseType.DB2) return "current timestamp FROM sysibm.sysdummy1";
                else return "getdate()";
            }
        }

        public DBUtilODBC(string ConnectionString, DatabaseType dbtype)
        {
            this.ConnectionString = ConnectionString;
            this.dbtype = dbtype;
        }
        public string Inserter(string table, Dictionary<string, string> Values)
        {
            Dictionary<string, TableSummary> Attributes = CacheGetCurrentAttributes(table);
            string SQL = "";
            string vals = "";
            try
            {
                 SQL = "INSERT into " + DBUtilODBC.bracketize(table) + " ("; // start a SQL insert statement
                 vals = "(";

                foreach (string field in Values.Keys) // loop through values to build sql
                {
                    if (Attributes.ContainsKey(field))
                    {
                        SQL += DBUtilODBC.bracketize(field) + ", ";
                        if (Attributes[field].DataType == "datetime" || Attributes[field].DataType == "date")
                        {
                            if (Values[field] == null || Values[field].ToString() == "") vals += "NULL, ";
                            else
                            {
                                DateTime dte = DateTime.Parse(Values[field].ToString());

                                if (dbtype == DatabaseType.ORACLE)
                                {
                                    vals += "to_date('" + dte.ToString(_DateTimeString) + "', '" + _DateTimeString + "'), ";
                                }
                                else
                                {
                                    vals += "'" + dte.ToString(_DateTimeString) + "', ";
                                }
                            }
                        }
                        else if (Attributes[field].DataType == "uniqueidentifier")
                        {
                            if (Values[field] != "" && Values[field] != null)
                            {
                                vals += "'" + SQLClean(Values[field]) + "', ";
                            }
                            else vals += "NULL, ";
                        }
                        else
                        {
                            if (Values[field] == null) vals += "NULL, ";
                            else
                            {
                                if (ContainsUnicodeCharacter(Values[field]) && dbtype != DatabaseType.ACCESS) vals += 'N';
                                vals += "'" + SQLClean(Values[field]) + "', ";
                            }
                        }
                    }
                    else
                    {
                        SQL += DBUtilODBC.bracketize(field) + ", ";

                        if (ContainsUnicodeCharacter(Values[field]) && dbtype != DatabaseType.ACCESS) vals += 'N';
                        vals += "'" + SQLClean(Values[field]) + "', ";
                    }
                }
                SQL = SQL.Trim(new char[] { ',', ' ' }) + ")"; // remove extra coma, close the list
                vals = vals.Trim(new char[] { ',', ' ' }) + ")";

                return SQL + " values " + vals; // put it all together as a finished SQL Insert statement
            }
            catch (Exception ex)
            {
                if (Values == null) ztLogging.Logger.Error("Values was null");
                if (Attributes == null) ztLogging.Logger.Error("Attributes was null");
                ztLogging.Logger.Error(ex, "Error in Iserter.");
                ztLogging.Logger.Error("SQL: " + SQL);
                ztLogging.Logger.Error("VALS: " + vals);
                throw;
            }
        }
        public string Updater(string table, string PrimaryKey, Dictionary<string, string> Values)
        {
            Dictionary<string, TableSummary> Attributes = CacheGetCurrentAttributes(table);

            string SQL = "UPDATE " + DBUtilODBC.bracketize(table) + " set "; // start a SQL insert statement

            foreach (string field in Values.Keys) // loop through values to build sql
            {
                if (Attributes.ContainsKey(field) && field != PrimaryKey)
                {
                    SQL += DBUtilODBC.bracketize(field) + " = ";
                    if (Attributes[field].DataType.ToLower() == "datetime" || Attributes[field].DataType.ToLower()=="date")
                    {
                        if (string.IsNullOrEmpty(Values[field])) { SQL += "null, "; }
                        else
                        {
                            DateTime dte = DateTime.Parse(Values[field].ToString());
                            if (dbtype == DatabaseType.ORACLE)
                            {
                                SQL += "to_date('" + dte.ToString(_DateTimeString) + "', '" + _DateTimeString + "'), ";
                            }
                            else
                            {
                                SQL += "'" + dte.ToString(_DateTimeString) + "', ";
                            }
                        }
                    }
                    else
                    {
                        if (Values[field] == null /*|| string.IsNullOrEmpty(Values[field].ToString())*/) { SQL += "null, "; }
                        else
                        {
                            if (ContainsUnicodeCharacter(Values[field]) && dbtype != DatabaseType.ACCESS) SQL += 'N';
                            SQL += "'" + SQLClean(Values[field]) + "', ";
                        }
                    }
                }
                else if (field != PrimaryKey) // field not in metadata (maybe there is no metadata?) - treat as generic string format
                {
                    SQL += DBUtilODBC.bracketize(field) + " = ";

                    if (ContainsUnicodeCharacter(Values[field]) && dbtype != DatabaseType.ACCESS)
                        SQL += 'N';
                    SQL += "'" + SQLClean(Values[field]) + "', ";
                }
            }
            SQL = SQL.Trim(new char[] { ',', ' ' }); // remove extra coma, close the list

            if (Attributes[PrimaryKey].DataType.ToLower().Contains("int"))
            {
                SQL += " WHERE " + PrimaryKey + " = " + Values[PrimaryKey] + "";
            }
            else
            {
                SQL += " WHERE " + PrimaryKey + " = '" + Values[PrimaryKey] + "'";
            }
            return SQL;
        }
        public string Deleter(string table, string PrimaryKey, string KeyVal)
        {
            return "DELETE FROM " + bracketize(table) + " where " + bracketize(PrimaryKey) + "='" + SQLClean(KeyVal) + "'";
            
        }


        public bool DoesAtLeastOneRecordExist(string table, string PrimaryKey, string KeyVal)
        {
            string select = "";
            if (dbtype == DatabaseType.MYSQL)
            {
                select = "select " + bracketize(PrimaryKey) + " from " + bracketize(table) + " where " + bracketize(PrimaryKey) + "='" + SQLClean(KeyVal) + "' limit 1";
            }
            else if (dbtype == DatabaseType.ORACLE)
            {
                select = "select " + bracketize(PrimaryKey) + " from " + bracketize(table) + " where " + bracketize(PrimaryKey) + "='" + SQLClean(KeyVal) + "'";
            }
            else if (dbtype == DatabaseType.DB2)
            {
                select = "select " + PrimaryKey + " from " + table + " where " + PrimaryKey + "='" + SQLClean(KeyVal) + "' FETCH FIRST 1 ROWS ONLY";
            }
            else
            {
                select = "select top 1 " + bracketize(PrimaryKey) + " from " + bracketize(table) + " where " + bracketize(PrimaryKey) + "='" + SQLClean(KeyVal) + "'";
            }

            try
            {
                return CountRows(select) >= 1;
            }
            catch (Exception ex)
            {
                Exception ex2 = new Exception("DoesAtLeastOnerecordExist Query: " + select, ex);
                throw ex2;
            }
        }
        public List<string> GetColumns(string SQL)
        {
            List<string> Columns = new List<string>();
            try
            {
                OdbcConnection cn = new OdbcConnection();
                OdbcCommand cmd = new OdbcCommand();
                cn.ConnectionString = ConnectionString;
                cn.Open();
                cmd.Connection = cn;
                cmd.CommandText = SQL;
                cmd.CommandTimeout = 30 * 60; // 30 minutes

                using (var reader = cmd.ExecuteReader())
                {
                    reader.Read();
                    var table = reader.GetSchemaTable();
                    foreach (DataRow row in table.Rows)
                    {
                        Columns.Add(row["ColumnName"].ToString());
                    }
                }
                cn.Close();
            }
            catch (Exception ex)
            {
                throw new Exception("Error getting columns. " + ex.ToString());
            }
            return Columns;
        }
        public int CountRows(string SQL)
        {
            List<string> Columns = new List<string>();
            OdbcConnection cn = new OdbcConnection();
            OdbcCommand cmd = new OdbcCommand();
            cn.ConnectionString = ConnectionString;
            cn.Open();
            cmd.Connection = cn;
            cmd.CommandText = SQL;
            cmd.CommandTimeout = 30 * 60; // 30 minutes

            int count = 0;
            using (var reader = cmd.ExecuteReader())
            {

                while (reader.Read())
                {
                    count++;
                }
            }
            cn.Close();
            return count;
        }
        public OdbcDataReader GetReader(string SQL)
        {
            List<string> Columns = new List<string>();
            OdbcConnection cn = new OdbcConnection();
            OdbcCommand cmd = new OdbcCommand();
            cn.ConnectionString = ConnectionString;
            cn.Open();
            cmd.Connection = cn;
            cmd.CommandText = SQL;
            cmd.CommandTimeout = 30 * 60; // 30 minutes

            return cmd.ExecuteReader();
        }
        public DataSet GetDataSet(string sql)
        {
            OdbcConnection cn = new OdbcConnection();
            cn.ConnectionString = ConnectionString;

            string selectQueryString = sql;
            DataSet dataSet = new DataSet();
            using (OdbcCommand command = new OdbcCommand(selectQueryString, cn))
            {
                
                command.CommandTimeout = 60 * 60;// 60 minutes
                using (OdbcDataAdapter odbcAdapter = new OdbcDataAdapter(command))
                {
                    cn.Open();
                    odbcAdapter.Fill(dataSet);
                    cn.Close();
                }
            }

            return dataSet;
        }
        public string GetConnString()
        {
            return this.ConnectionString;
        }
        public int ExecSQL(string SQL, bool CloseConnection=true)
        {
            if (this.dbtype == DatabaseType.SqlCompact) // no ODBC connection to SQL CE unfortunately :-(
            {
                SqlCeConnection conn = new SqlCeConnection();
                conn.ConnectionString = this.ConnectionString;
                using (SqlCeCommand command = new SqlCeCommand(SQL, conn))
                {
                    try
                    {
                        command.CommandTimeout = 0;//CE only allows zero 60 * 60;// 60 minutes                
                        conn.Open();
                        return command.ExecuteNonQuery();
                    }
                    finally
                    {
                        if (CloseConnection) conn.Close();
                    }
                }
            }
            else
            {

                OdbcConnection cn = new OdbcConnection();
                OdbcCommand cmd = new OdbcCommand();
                cn.ConnectionString = ConnectionString;
                cn.Open();
                cmd.Connection = cn;
                cmd.CommandText = SQL;

                int result = cmd.ExecuteNonQuery();
                if (CloseConnection)
                {
                    cn.Close();
                    cn.Dispose();
                }
                cmd.Dispose();
                return result;
            }
        }

        protected Dictionary<string, Dictionary<string, TableSummary>> SchemaCache = new Dictionary<string, Dictionary<string, TableSummary>>();
        public Dictionary<string, TableSummary> GetCurrentAttributes(string tablename)
        {
            try
            {
                Dictionary<string, TableSummary> results = new Dictionary<string, TableSummary>();

                if (dbtype == DatabaseType.MSSQL || dbtype == DatabaseType.ODBC || dbtype == null)
                {
                    OdbcDataReader rdr = this.GetReader("SELECT c.name AS column_name, ty.name as column_type, c.max_length FROM sys.tables AS t INNER JOIN sys.columns c ON t.OBJECT_ID = c.OBJECT_ID  INNER JOIN sys.types ty on C.system_type_id=ty.system_type_id where t.name = '" + tablename + "'");
                    {

                        while (rdr.Read())
                        {
                            TableSummary ts = new TableSummary();
                            ts.AttributeSchemaName = rdr[0].ToString();
                            ts.DataType = rdr[1].ToString();
                            ts.DisplayName = ts.AttributeSchemaName;
                            ts.EntityName = tablename;
                            ts.MaxLength = Convert.ToInt32(rdr[2].ToString());

                            if (!results.ContainsKey(ts.AttributeSchemaName)) results.Add(ts.AttributeSchemaName, ts);
                        }
                    }
                }
                else if (dbtype == DatabaseType.ORACLE)
                {
                    OdbcDataReader rdr = this.GetReader("SELECT column_name, data_type, data_length, nullable, data_precision from cols where table_name = '" + tablename + "'");
                    {
                        while (rdr.Read())
                        {
                            TableSummary ts = new TableSummary();
                            ts.AttributeSchemaName = rdr[0].ToString();
                            ts.DataType = rdr[1].ToString();
                            ts.DisplayName = ts.AttributeSchemaName;
                            ts.EntityName = tablename;
                            ts.MaxLength = Convert.ToInt32(rdr[2].ToString());

                            if (!results.ContainsKey(ts.AttributeSchemaName)) results.Add(ts.AttributeSchemaName, ts);
                        }
                    }
                }
                else if (dbtype == DatabaseType.DB2)
                {
                    OdbcDataReader rdr = this.GetReader("SELECT COLUMN_NAME as column_name, DATA_TYPE as data_type, LENGTH as data_length, IS_NULLABLE as nullable, NUMERIC_PRECISION as data_precision FROM QSYS2.SYSCOLUMNS WHERE TABLE_NAME = '" + tablename.ToUpper() + "'");
                    {
                        while (rdr.Read())
                        {
                            TableSummary ts = new TableSummary();
                            ts.AttributeSchemaName = rdr[0].ToString();
                            ts.DataType = rdr[1].ToString();
                            ts.DisplayName = ts.AttributeSchemaName;
                            ts.EntityName = tablename;
                            ts.MaxLength = Convert.ToInt32(rdr[2].ToString());

                            if (!results.ContainsKey(ts.AttributeSchemaName)) results.Add(ts.AttributeSchemaName, ts);
                        }
                    }
                }
                else if (dbtype == DatabaseType.QODBC)
                {
                    OdbcDataReader rdr = this.GetReader("SP_COLUMNS '" + tablename + "'");
                    {

                        while (rdr.Read())
                        {
                            TableSummary ts = new TableSummary();
                            ts.AttributeSchemaName = rdr[3].ToString();
                            ts.DataType = rdr[5].ToString();
                            ts.DisplayName = ts.AttributeSchemaName;
                            ts.EntityName = tablename;
                            ts.MaxLength = Convert.ToInt32(rdr[6].ToString());

                            if (!results.ContainsKey(ts.AttributeSchemaName)) results.Add(ts.AttributeSchemaName, ts);
                        }
                    }
                }
                else if (dbtype == DatabaseType.MYSQL)
                {
                    OdbcDataReader rdr = this.GetReader("select column_name, data_type as column_type, character_maximum_length as max_length from information_schema.columns where table_name='" + tablename + "' order by 1");
                    {

                        while (rdr.Read())
                        {
                            TableSummary ts = new TableSummary();
                            ts.AttributeSchemaName = rdr[0].ToString();
                            ts.DataType = rdr[1].ToString();
                            ts.DisplayName = ts.AttributeSchemaName;
                            ts.EntityName = tablename;
                            ts.MaxLength = Convert.ToInt32(rdr[2].ToString());

                            if (!results.ContainsKey(ts.AttributeSchemaName)) results.Add(ts.AttributeSchemaName, ts);
                        }
                    }
                }
                else if (dbtype == DatabaseType.ACCESS || dbtype == DatabaseType.MYSQL)
                {
                    OdbcDataReader rdr = this.GetReader("select * from '" + tablename + "' where 1=0");
                    {

                        while (rdr.Read())
                        {
                            DataTable schemaTable = rdr.GetSchemaTable();

                            //For each field in the table...
                            foreach (DataRow myField in schemaTable.Rows)
                            {
                                //For each property of the field...
                                foreach (DataColumn myProperty in schemaTable.Columns)
                                {
                                    //Display the field name and value.
                                    Console.WriteLine(myProperty.ColumnName + " = " + myField[myProperty].ToString());

                                    TableSummary ts = new TableSummary();
                                    ts.AttributeSchemaName = myProperty.ColumnName;
                                    ts.DataType = myProperty.DataType.ToString();
                                    ts.DisplayName = ts.AttributeSchemaName;
                                    ts.EntityName = tablename;
                                    ts.MaxLength = myProperty.MaxLength;

                                    if (!results.ContainsKey(ts.AttributeSchemaName)) results.Add(ts.AttributeSchemaName, ts);
                                }
                            }
                        }
                    }
                }                

                return results;
            }
            catch (Exception ex) // usually a non-MSSQL db
            {
                ztLogging.Logger.Error(ex, "Unable to retrieve column schema");
                return new Dictionary<string, TableSummary>();
            }

        }

        public List<string> GetTables()
        {
            try
            {
                List<string> results = new List<string>();
                if (dbtype == DatabaseType.MSSQL || dbtype == DatabaseType.ODBC)
                {
                    OdbcDataReader rdr = this.GetReader("SELECT name from sys.tables order by 1");
                    {
                        while (rdr.Read())
                        {
                            results.Add(rdr[0].ToString());
                        }
                    }
                }
                else if (dbtype == DatabaseType.ORACLE)
                {
                    OdbcDataReader rdr = this.GetReader("SELECT table_name from all_tables order by 1");
                    {
                        while (rdr.Read())
                        {
                            results.Add(rdr[0].ToString());
                        }
                    }
                }

                else if (dbtype == DatabaseType.DB2)
                {

                    OdbcDataReader rdr = this.GetReader("SELECT TABLE_NAME from QSYS2.SYSTABLES WHERE TABLE_SCHEMA = 'V10OCRM42' AND TABLE_TYPE = 'P'");
                    {
                        while (rdr.Read())
                        {
                            results.Add(rdr[0].ToString());
                        }
                    }
                }

                else if (dbtype == DatabaseType.ACCESS)
                {
                    OdbcDataReader rdr = this.GetReader("SELECT Name FROM MSysObjects WHERE  Left([Name],1)<>'~'  AND  Left([Name],4)<>'MSys' AND Type In (1,4,6) ORDER BY Name");
                    {
                        while (rdr.Read())
                        {
                            results.Add(rdr[0].ToString());
                        }
                    }
                }

                else if (dbtype == DatabaseType.QODBC)
                {
                    OdbcDataReader rdr = this.GetReader("SP_TABLES");
                    {
                        while (rdr.Read())
                        {
                            results.Add(rdr[2].ToString());
                        }
                    }
                }
                else if (dbtype == DatabaseType.MYSQL)
                {
                    try
                    {
                        ztLogging.Logger.Info("Getting MySQL Tables");
                        OdbcDataReader rdr = this.GetReader("SELECT table_name FROM information_schema.tables where table_schema=SCHEMA() ORDER BY table_name");
                        {
                            while (rdr.Read())
                            {
                                ztLogging.Logger.Info("MySQL Table Found");
                                results.Add(rdr[0].ToString());
                            }
                        }
                        ztLogging.Logger.Info("Finished Getting MySQL Tables");
                        if (results.Count <= 0) ztLogging.Logger.Error("Error: no tables found. Ensure you have specified a default schema in your DSN connection.");
                    }
                    catch (Exception ex)
                    {
                        ztLogging.Logger.Warn(ex, "Eror retrieving MySQL table list");
                    }
                }

                return results;

            }
            catch (Exception ex) // non MSSQL
            {
                ztLogging.Logger.Warn(ex, "Error retrieving table list");
                return new List<string>();
            }
        }

        protected Dictionary<string, TableSummary> CacheGetCurrentAttributes(string tablename)
        {
            if (this.SchemaCache.ContainsKey(tablename)) return this.SchemaCache[tablename];
            else
            {
                this.SchemaCache.Add(tablename, GetCurrentAttributes(tablename));
                return this.SchemaCache[tablename];
            }
        }
        public TableSummary GetAttribute(string tablename, string attributename)
        {
            CacheGetCurrentAttributes(tablename); //precache as necessary
            if (this.SchemaCache.ContainsKey(tablename) && this.SchemaCache[tablename].ContainsKey(attributename))
                return this.SchemaCache[tablename][attributename];
            else return null;
        }
        public static string bracketize(string value)
        {
            if (!value.Replace('_', 'Z').All(char.IsLetterOrDigit) || !Char.IsLetter(value.FirstOrDefault())) // allow _ without brackets due to Oracle
            {
                if (value.Contains("[") || value.Contains(".")) return value;
                else
                    return '[' + value + ']';
            }
            else return value;
        }
        public bool ContainsUnicodeCharacter(string input)
        {
            if (input == null)
                return false;
            const int MaxAnsiCode = 255;

            return input.ToCharArray().Any(c => c > MaxAnsiCode);
        }
        protected string SQLClean(string val)
        {
            if (val == null) return "";
            else return val.Replace("'", "''");
        }
        protected string SQLClean(DateTime val)
        {
            if (val == null) return "";
            else if (val == DateTime.MinValue) return "";
            else return val.ToString();
        }


        public string DateFormatString { get { return this._DateTimeString; } set { this._DateTimeString = value; } }
    }

    public class TableSummary
    {
        public string EntityName;
        public string AttributeSchemaName;
        public int MaxLength;
        public string RelatedEntityName;
        public string DisplayName;
        public string DataType;
    }
    public enum DatabaseType
    {
        MSSQL, ORACLE, ODBC, QODBC, ACCESS, MYSQL, SqlCompact, DB2
    };
}

﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ztLogging;

namespace fsCore2016
{
    public class Connect
    {


        static Connect()
        {
            AppDomain.CurrentDomain.ProcessExit += new EventHandler(OnProcessExit);
        }

        public static IOrganizationService GetOrganizationServiceClientSecret(string clientId, string clientSecret, string organizationUri)
        {
            try
            {
                CrmServiceClient.MaxConnectionTimeout = new TimeSpan(0, 10, 0);
                var conn = new CrmServiceClient($@"AuthType=ClientSecret;url={organizationUri};ClientId={clientId};ClientSecret={clientSecret}");
                if ( !string.IsNullOrEmpty(conn.LastCrmError))
                {
                    Logger.Error("CrmServiceClient Last CRM Error : " + conn.LastCrmError);
                }

                return conn.OrganizationWebProxyClient != null ? conn.OrganizationWebProxyClient : (IOrganizationService)conn.OrganizationServiceProxy;
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                return null;
            }
        }

        public static IOrganizationService GetOrganizationService(string userName, string password, string loginUri)
        {
            try
            {
                CrmServiceClient.MaxConnectionTimeout = new TimeSpan(0, 10, 0);
                var conn = new CrmServiceClient($@"Url={loginUri}; Username={userName}; Password={password}; authtype=Office365");
                if (!string.IsNullOrEmpty(conn.LastCrmError))
                {
                    Logger.Error("CrmServiceClient Last CRM Error : " + conn.LastCrmError);
                }
                // Cast the proxy client to the IOrganizationService interface.
                return conn.OrganizationWebProxyClient != null ? conn.OrganizationWebProxyClient : (IOrganizationService)conn.OrganizationServiceProxy;
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                return null;
            }
        }





        public static OrganizationResponse CallAction(IOrganizationService service, string actionName, EntityReference target, Dictionary<string, object> parameters = null)
        {
            var request = new OrganizationRequest(actionName);

            if (!(parameters == null))
            {
                parameters.ToList().ForEach(kv =>
                {
                    request.Parameters.Add(kv.Key, kv.Value);
                });
            }

            request.Parameters.Add("Target", target);

            var response = service.Execute(request);
            return response;
        }

        static void OnProcessExit(object sender, EventArgs e)
        {

        }
    }
}

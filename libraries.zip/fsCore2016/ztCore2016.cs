﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Xml;
using System.Web;

using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Crm.Sdk.Samples;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

using System.Configuration;
using System.Globalization;
using ztLogging;

using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using Microsoft.Xrm.Sdk.WebServiceClient;

namespace fsCore2016
{
    public class fsCore2016 : ztCore2011
    {
        public fsCore2016() : base() { }
    }
    public partial class ztCore2011
    {
        private bool _loggedin = false;
        private IOrganizationService _serviceProxy = null;
        private Dictionary<string, Dictionary<String, int>> PicklistCache = new Dictionary<string, Dictionary<string, int>>();
        public Dictionary<string, Dictionary<String, Guid>> EntityCache = new Dictionary<string, Dictionary<string, Guid>>(StringComparer.OrdinalIgnoreCase);
        private string _servername = ""; // set via Login
        private string _orgname = ""; // set via Login
        private CultureInfo RuntimeCulture;
        private string _defaultPrefix = "";
        private Guid _callerid;
        
        public IOrganizationService Service
        {
            get
            {
                return _serviceProxy;
            }
            set
            {
                _serviceProxy = value;
            }
        }

        public Guid CallerId
        {
            get
            {
                if (_serviceProxy.GetType().ToString() == "Microsoft.Xrm.Sdk.WebServiceClient.OrganizationWebProxyClient")
                {
                    _callerid = ((OrganizationWebProxyClient)_serviceProxy).CallerId;
                } else
                {
                    _callerid = ((OrganizationServiceProxy)_serviceProxy).CallerId;
                }
                return _callerid;
            }
            set
            {
                _callerid = value;
                if (_serviceProxy.GetType().ToString() == "Microsoft.Xrm.Sdk.WebServiceClient.OrganizationWebProxyClient")
                {
                    ((OrganizationWebProxyClient)_serviceProxy).CallerId = _callerid;
                }
                else
                {
                    ((OrganizationServiceProxy)_serviceProxy).CallerId = _callerid;
                }
            }
        }

        public void EnableProxyTypes()
        {
            if (_serviceProxy.GetType().ToString() != "Microsoft.Xrm.Sdk.WebServiceClient.OrganizationWebProxyClient")
            {
                ((OrganizationServiceProxy)_serviceProxy).EnableProxyTypes();
            }
        }

        public bool IsLoggedIn
        {
            get
            {
                return _loggedin;
            }
        }

        public ztCore2011()
        {
            this.fetchPropertyDelimiter = ConfigurationManager.AppSettings["CRMfetchPropertyDelimiter"] ?? ".";

            string sCulture = ConfigurationManager.AppSettings["CultureToUse"];

            if (!string.IsNullOrEmpty(sCulture))
            {
                RuntimeCulture = CultureInfo.CreateSpecificCulture(sCulture);
            }
            else
            {
                RuntimeCulture = CultureInfo.CurrentCulture; // use machine culture if none is specified
            }
           // Logger.Debug("ztCore Loaded.  Culture: " + RuntimeCulture.EnglishName);
        }

        private bool IsProxyInCache(string key)
        {

            try
            {
                _serviceProxy = (IOrganizationService)HttpRuntime.Cache.Get(key);

                if (_serviceProxy != null)
                {
                    //_serviceProxy.RefreshSecurityToken();
                    return true;
                }
            }
            catch (Exception)
            {

            }

            return false;
        }

        private Guid _WhoAmI;
        public Guid WhoAmI()
        {
            if (_WhoAmI == null || _WhoAmI == Guid.Empty)
            {
                _WhoAmI = ((WhoAmIResponse)Service.Execute(new WhoAmIRequest())).UserId;
            }
            return _WhoAmI;
        }

        public string GetPrimaryField(string entityName)
        {
            RetrieveEntityRequest entityRequest;
            RetrieveEntityResponse response;
            if (entityName == "listmember")
            {
                return "listmemberid";
            }
            else
            {
                try
                {
                    entityRequest = new RetrieveEntityRequest()
                    {
                        LogicalName = entityName,
                        EntityFilters = EntityFilters.Attributes,
                        RetrieveAsIfPublished = true,
                    };

                    response = (RetrieveEntityResponse)this.Execute(entityRequest);
                }
                catch
                {
                    entityRequest = new RetrieveEntityRequest()
                    {
                        LogicalName = entityName,
                        EntityFilters = EntityFilters.Attributes,
                        RetrieveAsIfPublished = false,
                    };

                    response = (RetrieveEntityResponse)this.Execute(entityRequest);
                }

                EntityMetadata currentEntity = response.EntityMetadata;
                return currentEntity.PrimaryNameAttribute;
            }
           
        }

        public string GetPrimaryKey(string EntityName)
        {
            try
            {
                //DB - Changed to return primary key from schemaCache.
                if (this.SchemaCache[EntityName] != null)
                    return this.SchemaCache[EntityName].First().Value.PrimaryKey;

                string ActivityEntities = ";activitypointer;appointment;serviceappointment;recurringappointmentmaster;campaignactivity;campaignresponse;opportunityclose;orderclose;quoteclose;incidentresolution;letter;fax;email;phonecall;task;psa_projectitem;";

                if (this.SchemaCache.ContainsKey(EntityName))
                {
                    return SchemaCache[EntityName].ContainsKey("activityid") ? "activityid" : EntityName.ToLower() + "id";
                    //if (SchemaCache[EntityName].ContainsKey("activityid"))
                    //    return "activityid";
                    //else
                    //    return EntityName.ToLower() + "id";
                }

                if (ActivityEntities.Contains(";" + EntityName.ToLower() + ";"))
                    return "activityid";

                return EntityName.ToLower() == "usersettings" ? "systemuserid" : EntityName.ToLower() + "id";
                //else if (EntityName.ToLower() == "usersettings")
                //    return "systemuserid";
                //else
                //    return EntityName.ToLower() + "id";
            }
            catch (Exception ex)
            {
                Logger.Error(ex.Message);
            }
            return string.Empty;

        }
        public OrganizationRequest GetRequestReAssign(EntityReference TargetEntity, EntityReference Owner)
        {
            AssignRequest assign = new AssignRequest();

            assign.Assignee = Owner;
            assign.Target = TargetEntity;
            return assign;

        }
        public OrganizationResponse ReAssign(EntityReference TargetEntity, EntityReference Owner)
        {
            return this.Execute(GetRequestReAssign(TargetEntity, Owner));
        }

        public Dictionary<int?, string> GetPicklistValues(string entityName, string AttributeName)
        {
            Dictionary<int?, string> results = new Dictionary<int?, string>();

            RetrieveAttributeRequest attributeRequest;
            RetrieveAttributeResponse attributeResponse;

            try
            {

                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = true;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }
            catch
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = false;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }
            
            PicklistAttributeMetadata retrievedAttributeMetadata = (PicklistAttributeMetadata)attributeResponse.AttributeMetadata;

            foreach (OptionMetadata anOption in retrievedAttributeMetadata.OptionSet.Options)
            {
                foreach (LocalizedLabel aLocLabel in anOption.Label.LocalizedLabels)
                {
                    results.Add(anOption.Value, aLocLabel.Label);
                }
            }
            return (results);
        }
        public Dictionary<int?, string> GetMultiSelectOptionSetValues(string entityName, string AttributeName)
        {
            Dictionary<int?, string> results = new Dictionary<int?, string>();

            RetrieveAttributeRequest attributeRequest;
            RetrieveAttributeResponse attributeResponse;

            try
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = true;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }
            catch
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = false;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }

            MultiSelectPicklistAttributeMetadata retrievedAttributeMetadata = (MultiSelectPicklistAttributeMetadata)attributeResponse.AttributeMetadata;

            foreach (OptionMetadata anOption in retrievedAttributeMetadata.OptionSet.Options)
            {
                foreach (LocalizedLabel aLocLabel in anOption.Label.LocalizedLabels)
                {
                    results.Add(anOption.Value, aLocLabel.Label);
                }
            }
            return (results);
        }
        public AddListMembersListRequest GetRequestAddMarketingListMember(EntityReference ListReference, EntityReference ContactOrLeadOrAccountIDReference)
        {
            AddListMembersListRequest req = new AddListMembersListRequest();
            req.ListId = ListReference.Id;
            req.MemberIds = new Guid[] { ContactOrLeadOrAccountIDReference.Id };
            return req;
        }
        public AddMembersTeamRequest GetRequestAddMembersTeam(EntityReference TeamReference, EntityReference UserReference)
        {
            AddMembersTeamRequest req = new AddMembersTeamRequest();
            req.TeamId = TeamReference.Id;
            req.MemberIds = new Guid[] { UserReference.Id };
            return req;
        }
        public AddMembersTeamRequest GetRequestAddMembersTeam(Guid TeamReference, Guid UserReference)
        {
            AddMembersTeamRequest req = new AddMembersTeamRequest();
            req.TeamId = TeamReference;
            req.MemberIds = new Guid[] { UserReference };
            return req;
        }

        public RemoveMembersTeamRequest GetRequestRemoveMembersTeam(EntityReference TeamReference, EntityReference UserReference)
        {
            RemoveMembersTeamRequest req = new RemoveMembersTeamRequest();
            req.TeamId = TeamReference.Id;
            req.MemberIds = new Guid[] { UserReference.Id };
            return req;
        }
        public RemoveMembersTeamRequest GetRequestRemoveMembersTeam(Guid TeamReference, Guid UserReference)
        {
            RemoveMembersTeamRequest req = new RemoveMembersTeamRequest();
            req.TeamId = TeamReference;
            req.MemberIds = new Guid[] { UserReference };
            return req;
        }

        public void AddMarketingListMember(EntityReference ListReference, EntityReference ContactOrLeadOrAccountIDReference)
        {
            var req = GetRequestAddMarketingListMember(ListReference, ContactOrLeadOrAccountIDReference);
            AddListMembersListResponse resp = (AddListMembersListResponse)this.Service.Execute(req);
        }
        public void AddTeamMember(EntityReference TeamRef, EntityReference UserRef)
        {
            var req = GetRequestAddMembersTeam(TeamRef, UserRef);
            AddMembersTeamResponse resp = (AddMembersTeamResponse)this.Service.Execute(req);
        }
        public void AddTeamMember(Guid TeamRef, Guid UserRef)
        {
            var req = GetRequestAddMembersTeam(TeamRef, UserRef);
            AddMembersTeamResponse resp = (AddMembersTeamResponse)this.Service.Execute(req);
        }

        public void RemoveTeamMember(EntityReference TeamRef, EntityReference UserRef)
        {
            var req = GetRequestRemoveMembersTeam(TeamRef, UserRef);
            RemoveMembersTeamResponse resp = (RemoveMembersTeamResponse)this.Service.Execute(req);
        }
        public void RemoveTeamMember(Guid TeamRef, Guid UserRef)
        {
            var req = GetRequestRemoveMembersTeam(TeamRef, UserRef);
            RemoveMembersTeamResponse resp = (RemoveMembersTeamResponse)this.Service.Execute(req);
        }

        public void AddCampaignItem(EntityReference CampaignReference, EntityReference CampaignItemReference)
        {
            AddItemCampaignRequest req = new AddItemCampaignRequest();
            req.CampaignId = CampaignReference.Id;
            req.EntityId = CampaignItemReference.Id;
            req.EntityName = CampaignItemReference.LogicalName;

            AddItemCampaignResponse resp = (AddItemCampaignResponse)this.Service.Execute(req);
        }

        public string GetStatusCodeString(string entityName, string attributeName, int ListValue)
        {


            OptionMetadataCollection wod_ReturnOptionsCollection = null;
            RetrieveEntityRequest wod_RetrieveEntityRequest = new RetrieveEntityRequest();
            RetrieveEntityResponse wod_RetrieveEntityResponse = new RetrieveEntityResponse();

            wod_RetrieveEntityRequest.LogicalName = entityName;

            wod_RetrieveEntityRequest.EntityFilters = Microsoft.Xrm.Sdk.Metadata.EntityFilters.Attributes;

            wod_RetrieveEntityResponse = (RetrieveEntityResponse)this.Service.Execute(wod_RetrieveEntityRequest);

            foreach (AttributeMetadata wod_AttributeMetadata in wod_RetrieveEntityResponse.EntityMetadata.Attributes)
            {
                if (wod_AttributeMetadata.AttributeType == AttributeTypeCode.Status &&
                    wod_AttributeMetadata.LogicalName == attributeName)
                {
                    wod_ReturnOptionsCollection = ((StatusAttributeMetadata)wod_AttributeMetadata).OptionSet.Options;
                    break;
                }
            }

            foreach (OptionMetadata op in wod_ReturnOptionsCollection)
            {
                if (op.Value.Value == ListValue)
                {
                    return op.Label.LocalizedLabels[0].Label.ToString();
                }
            }

            return string.Empty;
        }

        public string GetOptionSetCodeString(string entityName, string attributeName, int ListValue)
        {


            OptionMetadataCollection wod_ReturnOptionsCollection = null;
            RetrieveEntityRequest wod_RetrieveEntityRequest = new RetrieveEntityRequest();
            RetrieveEntityResponse wod_RetrieveEntityResponse = new RetrieveEntityResponse();

            wod_RetrieveEntityRequest.LogicalName = entityName;

            wod_RetrieveEntityRequest.EntityFilters = Microsoft.Xrm.Sdk.Metadata.EntityFilters.Attributes;

            wod_RetrieveEntityResponse = (RetrieveEntityResponse)this.Service.Execute(wod_RetrieveEntityRequest);

            foreach (AttributeMetadata wod_AttributeMetadata in wod_RetrieveEntityResponse.EntityMetadata.Attributes)
            {
                if (wod_AttributeMetadata.AttributeType == AttributeTypeCode.Picklist &&
                    wod_AttributeMetadata.LogicalName == attributeName)
                {
                    wod_ReturnOptionsCollection = ((PicklistAttributeMetadata)wod_AttributeMetadata).OptionSet.Options;
                    break;
                }
            }

            foreach (OptionMetadata op in wod_ReturnOptionsCollection)
            {
                if (op.Value.Value == ListValue)
                {
                    return op.Label.LocalizedLabels[0].Label.ToString();
                }
            }

            return string.Empty;
        }
        public Dictionary<string, int> GetMutliSelectValueKeys(string entityName, string AttributeName)
        {
            Dictionary<string, int> results = new Dictionary<string, int>();

            RetrieveAttributeRequest attributeRequest;
            RetrieveAttributeResponse attributeResponse;

            try
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = true;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }
            catch
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = false;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }

            
            MultiSelectPicklistAttributeMetadata retrievedAttributeMetadata = (MultiSelectPicklistAttributeMetadata)attributeResponse.AttributeMetadata;

            foreach (OptionMetadata anOption in retrievedAttributeMetadata.OptionSet.Options)
            {
                foreach (LocalizedLabel aLocLabel in anOption.Label.LocalizedLabels)
                {
                    results.Add(aLocLabel.Label.ToLower(), anOption.Value.Value);
                }
            }
            return (results);
        }


        public Dictionary<string, int> GetPicklistValueKeys(string entityName, string AttributeName, bool trim = true, bool tolower = true)
        {
            Dictionary<string, int> results = new Dictionary<string, int>();

            RetrieveAttributeRequest attributeRequest;
            RetrieveAttributeResponse attributeResponse;

            try
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = true;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }
            catch
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = false;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }

            AttributeMetadata retrievedAttributeMetadata = (AttributeMetadata)attributeResponse.AttributeMetadata;

            //Added options for different Attribute Metadata - AH
            if (retrievedAttributeMetadata is PicklistAttributeMetadata)
            {
                foreach (OptionMetadata anOption in ((PicklistAttributeMetadata)retrievedAttributeMetadata).OptionSet.Options)
                {
                    GetResults(anOption, results, trim, tolower);
                }
            }
            else if (retrievedAttributeMetadata is StatusAttributeMetadata)
            {
                foreach (OptionMetadata anOption in ((StatusAttributeMetadata)retrievedAttributeMetadata).OptionSet.Options)
                {
                    GetResults(anOption, results, trim, tolower);
                }
            }
            else if (retrievedAttributeMetadata is StateAttributeMetadata)
            {
                foreach (OptionMetadata anOption in ((StateAttributeMetadata)retrievedAttributeMetadata).OptionSet.Options)
                {
                    GetResults(anOption, results, trim, tolower);
                }
            }

            return (results);
        }

        private void GetResults(OptionMetadata anOption, Dictionary<string, int> results, bool trim, bool tolower)
        {
            foreach (LocalizedLabel aLocLabel in anOption.Label.LocalizedLabels)
            {
                string label = aLocLabel.Label;
                if (trim) label = label.Trim();
                if (tolower) label = label.ToLower();

                if (!results.ContainsKey(label))
                {
                    results.Add(label, anOption.Value.Value);
                }
            }
        }

        public bool? ToBool(string val)
        {
            val = val.ToLower().Trim();
            return (val == "true" || val == "1" || val == "yes" || val == "y");
        }

        public Dictionary<string, Guid> PreCacheEntity(string EntityName, string SearchAttribute, string EntityKey = "")
        {
            Logger.Info("Pre-caching entity " + EntityName);

            if (EntityKey == "")
            {
                EntityKey = this.GetPrimaryKey(EntityName);
            }

            if (!EntityCache.ContainsKey(EntityName + SearchAttribute))
                this.EntityCache[EntityName + SearchAttribute] =
                    new Dictionary<string, Guid>(StringComparer.OrdinalIgnoreCase);

            string fetch = "<fetch mapping='logical' version='1.0'><entity name='" + EntityName +
                           "'><attribute name='" + EntityKey + "' /><attribute name='" + SearchAttribute +
                           "' /><filter><condition attribute='" + EntityKey +
                           "' operator='not-null' /></filter></entity></fetch>";

            int Page = 0;
            string Cookie = null;
            while (true)
            {
                Page++;
                DataSet ds = this.RunXML(fetch, Page, out Cookie, Cookie);
                if (!ds.Tables["Results"].Columns.Contains(EntityKey)) ds.Tables["Results"].Columns.Add(EntityKey);
                if (!ds.Tables["Results"].Columns.Contains(SearchAttribute))
                    ds.Tables["Results"].Columns.Add(SearchAttribute);

                foreach (DataRow dr in ds.Tables["Results"].Rows)
                {
                    string id = dr[EntityKey].ToString();
                    string val = dr[SearchAttribute].ToString();
                    this.EntityCacheAdd(EntityName, SearchAttribute, val, new Guid(id));
                }

                if (Cookie == null) break;
            }

            return this.EntityCache[EntityName + SearchAttribute];

        }
        public void EntityCacheAdd(string EntityName, string IndexAttribute, string index, Guid value)
        {
            if (!this.EntityCache.ContainsKey(EntityName + IndexAttribute))
                EntityCache.Add(EntityName + IndexAttribute, new Dictionary<string, Guid>(StringComparer.OrdinalIgnoreCase));
            if (!this.EntityCache[EntityName + IndexAttribute].ContainsKey(index))
                this.EntityCache[EntityName + IndexAttribute].Add(index, value);//removed .tolower from index.  it was causing no records to match -- ah

        }

        public void EntityCacheAdd(string EntityName, string PRIMARY_KEY, string index, Guid value, bool PreCacheEntity)
        {
            if (!this.EntityCache.ContainsKey(EntityName + PRIMARY_KEY))
            {
                if (PreCacheEntity)
                {
                    this.PreCacheEntity(EntityName, PRIMARY_KEY); // lazy loading cache
                }
                else this.EntityCache.Add(EntityName + PRIMARY_KEY, new Dictionary<string, Guid>(StringComparer.OrdinalIgnoreCase));
            }

            if (this.EntityCache[EntityName + PRIMARY_KEY].ContainsKey(index)) { }
            else this.EntityCache[EntityName + PRIMARY_KEY].Add(index, value);
        }

        public void DeleteImportRecords()
        {
            Dictionary<string, string> Imports = this.GetEntityCache("importfile", "importfileid", "importfileid");

            int i = 0;

            foreach (string id in Imports.Keys)
            {
                i++;
                Guid GID = new Guid(id);

                try
                {
                    this.Service.Delete("importfile", GID);
                }
                catch (Exception ex)
                {
                    Logger.Error(ex, "Error Deleting ImportRecords");
                }
            }
        }

        public Dictionary<string, string> GetEntityCache(string EntityName, string Indexed, string Index)
        {

            Dictionary<string, string> results = new Dictionary<string, string>();
            string fetch = "<fetch mapping='logical' version='1.0'><entity name='" + EntityName + "'><attribute name='" + Index + "' /><attribute name='" + Indexed + "' /><filter><condition attribute='" + Index + "' operator='not-null' /></filter></entity></fetch>";

            int Page = 0;
            string Cookie = null;
            while (true)
            {
                Page++;
                DataSet ds = this.RunXML(fetch, Page, out Cookie, Cookie);

                foreach (DataRow dr in ds.Tables["Results"].Rows)
                {
                    string id = dr[Indexed].ToString();
                    string val = dr[Index].ToString();
                    if (results.ContainsKey(val)) { }
                    else results.Add(val, id);
                }

                if (Cookie == null) break;
            }


            return results;
        }
        public Dictionary<Guid, Guid> GetOwnerCache(string EntityName)
        {
            string Index = this.GetPrimaryKey(EntityName);
            string Indexed = "ownerid";

            Dictionary<Guid, Guid> results = new Dictionary<Guid, Guid>();
            string fetch = "<fetch mapping='logical' version='1.0'><entity name='" + EntityName + "'><attribute name='" + Index + "' /><attribute name='" + Indexed + "' /><filter><condition attribute='" + Index + "' operator='not-null' /></filter></entity></fetch>";

            int Page = 0;
            string Cookie = null;
            while (true)
            {
                Page++;
                DataSet ds = this.RunXML(fetch, Page, out Cookie, Cookie);

                foreach (DataRow dr in ds.Tables["Results"].Rows)
                {
                    Guid id = new Guid(dr[Indexed].ToString());
                    Guid val = new Guid(dr[Index].ToString());
                    if (results.ContainsKey(val)) { }
                    else results.Add(val, id);
                }
                if (Cookie == null) break;
            }

            return results;
        }

        public DataTable GetPicklistValuesDT(string entityName, string AttributeName)
        {
            DataTable results = new DataTable();
            results.TableName = "options-" + entityName + "-" + AttributeName;
            results.Columns.Add("index");
            results.Columns.Add("value");

            RetrieveAttributeRequest attributeRequest;
            RetrieveAttributeResponse attributeResponse;

            try
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = true;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }
            catch
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = false;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }

                PicklistAttributeMetadata retrievedAttributeMetadata = (PicklistAttributeMetadata)attributeResponse.AttributeMetadata;

            results.Rows.Add(new String[] { "", "" }); // add a blank option
            foreach (OptionMetadata anOption in retrievedAttributeMetadata.OptionSet.Options)
            {
                foreach (LocalizedLabel aLocLabel in anOption.Label.LocalizedLabels)
                {
                    results.Rows.Add(new String[] { anOption.Value.ToString(), aLocLabel.Label });
                }
            }
            return (results);
        }

        public DataTable GetStatePicklistValuesDT(string entityName, string AttributeName)
        {
            DataTable results = new DataTable();
            results.TableName = "options-" + entityName + "-" + AttributeName;
            results.Columns.Add("index");
            results.Columns.Add("value");

            RetrieveAttributeRequest attributeRequest;
            RetrieveAttributeResponse attributeResponse;

            try
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = true;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }
            catch
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = false;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }
            
            StateAttributeMetadata retrievedAttributeMetadata = (StateAttributeMetadata)attributeResponse.AttributeMetadata;

            results.Rows.Add(new String[] { "", "" }); // add a blank option
            foreach (OptionMetadata anOption in retrievedAttributeMetadata.OptionSet.Options)
            {
                foreach (LocalizedLabel aLocLabel in anOption.Label.LocalizedLabels)
                {
                    results.Rows.Add(new String[] { anOption.Value.ToString(), aLocLabel.Label });
                }
            }
            return (results);
        }

        public DataTable GetStatusPicklistValuesDT(string entityName, string AttributeName)
        {
            DataTable results = new DataTable();
            results.TableName = "options-" + entityName + "-" + AttributeName;
            results.Columns.Add("index");
            results.Columns.Add("value");

            RetrieveAttributeRequest attributeRequest;
            RetrieveAttributeResponse attributeResponse;

            try
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = true;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }
            catch
            {
                attributeRequest = new RetrieveAttributeRequest();
                attributeRequest.EntityLogicalName = entityName;
                attributeRequest.LogicalName = AttributeName;
                attributeRequest.RetrieveAsIfPublished = false;

                attributeResponse = (RetrieveAttributeResponse)this.Service.Execute(attributeRequest);
            }

            StatusAttributeMetadata retrievedAttributeMetadata = (StatusAttributeMetadata)attributeResponse.AttributeMetadata;

            results.Rows.Add(new String[] { "", "" }); // add a blank option
            foreach (OptionMetadata anOption in retrievedAttributeMetadata.OptionSet.Options)
            {
                foreach (LocalizedLabel aLocLabel in anOption.Label.LocalizedLabels)
                {
                    results.Rows.Add(new String[] { anOption.Value.ToString(), aLocLabel.Label });
                }
            }
            return (results);
        }

        public DataTable GetLookUpValuesDT(string lookupEntityName)
        {
            DataTable results = new DataTable();
            results.TableName = "lookups-" + lookupEntityName;
            results.Columns.Add("index");
            results.Columns.Add("value");

            string primaryAttribute = GetPrimaryField(lookupEntityName);

            QueryExpression queryExpression = new QueryExpression(lookupEntityName);

            queryExpression.ColumnSet = new ColumnSet(primaryAttribute);

            EntityCollection entityCollection = this.Service.RetrieveMultiple(queryExpression);

            foreach (Entity service in entityCollection.Entities)
            {
                if (service.Contains(primaryAttribute))
                    results.Rows.Add(new String[] { service.Id.ToString(), (string)service[primaryAttribute] });

            }
            return (results);
        }



        public string GetPrimaryFieldFromFetchXML(string fetchXML)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(fetchXML);
            XmlNode attribute = doc.SelectSingleNode("fetch/entity");

            if (attribute != null && attribute.ChildNodes.Count > 0)
            {
                foreach (XmlNode node in attribute.ChildNodes)
                {
                    if (node.Attributes["name"].Value.Contains("name"))
                        return node.Attributes["name"].Value;

                }
                return string.Empty;
            }
            else
                return string.Empty;
        }

        public string GetLookupViewFetchXML(string entityname)
        {
            QueryExpression mySavedQuery = new QueryExpression
            {
                ColumnSet = new ColumnSet(true),
                EntityName = SavedQuery.EntityLogicalName,
                Criteria = new FilterExpression
                {
                    Conditions =
                            {
                                new ConditionExpression
                                {
                                    AttributeName = "querytype",
                                    Operator = ConditionOperator.Equal,
                                    Values = {64}
                                },
                                new ConditionExpression
                                {
                                    AttributeName = "returnedtypecode",
                                    Operator = ConditionOperator.Equal,
                                    Values = {entityname}
                                }
                            }
                }
            };
            RetrieveMultipleRequest retrieveSavedQueriesRequest = new RetrieveMultipleRequest { Query = mySavedQuery };
            RetrieveMultipleResponse retrieveSavedQueriesResponse = (RetrieveMultipleResponse)this.Execute(retrieveSavedQueriesRequest);

            if (retrieveSavedQueriesResponse != null && retrieveSavedQueriesResponse.EntityCollection.Entities.Count > 0)
            {
                DataCollection<Entity> savedQueries = retrieveSavedQueriesResponse.EntityCollection.Entities;
                string fetchXML = (string)savedQueries[0].Attributes["fetchxml"];
                return fetchXML;
            }
            return string.Empty;
        }


        public int AddOptionSetOption(string entityname, string attributename, string label, int languageCode = 1033)
        {
            try
            {
                InsertOptionValueRequest insertOptionValueRequest = new InsertOptionValueRequest
                    {
                        AttributeLogicalName = attributename,
                        EntityLogicalName = entityname,
                        Label = new Label(label, languageCode)
                    };

                // Execute the request.
                int insertOptionValue = ((InsertOptionValueResponse)this.Service.Execute(
                    insertOptionValueRequest)).NewOptionValue;
                return insertOptionValue;
            }
            catch (Exception ex)
            {

            }

            return 0;

        }

        public void AddGlobalOptionSetOption(string attributename, string label, int value = 100000000, int languageCode = 1033)
        {
            try
            {
                InsertOptionValueRequest insertRequest = new InsertOptionValueRequest
                {
                    OptionSetName = attributename,
                    Label = new Label(label, languageCode),
                    Value = value
                };
                this.Service.Execute(insertRequest);
            }
            catch (Exception ex)
            {
                Logger.Debug("No Global Picklist Found for field |" + attributename + ":" + value + "|");
            }

        }

        public OptionSetValueCollection GetMultiSelectOptionSetValueViaCache(string entityname, string fieldname, string val, string globalOptionSet, bool AddIfNotFound = false)
        {
            List<string> optionList = val.Trim(';').Split(';').ToList();
            OptionSetValueCollection options = new OptionSetValueCollection();
            int globalValue = 0;

            if (!PicklistCache.ContainsKey(entityname + fieldname)) // cache is not built
            {
                Logger.Info("Building Multi Select Option Set cache: " + entityname + fieldname);
                PicklistCache[entityname + fieldname] = this.GetMutliSelectValueKeys(entityname, fieldname);
            }

            // loop through values from delimited string
            foreach (var value in optionList)
            {
                if (!string.IsNullOrEmpty(value.Trim()))
                {
                    if (PicklistCache[entityname + fieldname].ContainsKey(value.Trim().ToLower())) // Found in cache
                    {
                        options.Add(new OptionSetValue(PicklistCache[entityname + fieldname][value.Trim().ToLower()]));
                    }
                    else
                    {
                        if (AddIfNotFound)
                        {
                            int intval;
                            if (String.IsNullOrEmpty(globalOptionSet))
                            {
                                intval = AddOptionSetOption(entityname, fieldname, value); // Add to CRM and return value
                                PicklistCache[entityname + fieldname].Add(value.ToLower(), intval); // Add to cache
                                options.Add(new OptionSetValue(intval)); // Add to collection which will set the value for the record
                            }
                            else
                            {
                                if (globalValue == 0) // first values of delimited string
                                    globalValue = PicklistCache[entityname + fieldname].Select(temp => temp.Value).Concat(new[] { 100000000 }).Max();

                                globalValue++;
                                AddGlobalOptionSetOption(globalOptionSet, value, globalValue);
                                PicklistCache[entityname + fieldname].Add(value.ToLower(), globalValue); // Add to cache
                                options.Add(new OptionSetValue(globalValue)); // Add to collection which will set the value for the record

                            }
                        }
                    }
                }
            }

            if (options.Count > 0)
                return options;
            else
            {
                Logger.Debug("No Multi Select Option Set Found for field |" + fieldname + ":" + val + "|");
                return null;
            }
        }

        public OptionSetValueCollection GetMultiSelectOptionSetValueViaCache(string entityname, string fieldname, string val, bool AddIfNotFound = false)
        {
            List<string> optionList = val.Trim(';').Split(';').ToList();
            OptionSetValueCollection options = new OptionSetValueCollection();
            int intval;

            if (!PicklistCache.ContainsKey(entityname + fieldname)) // cache is not built
            {
                Logger.Info("Building Multi Select Option Set cache: " + entityname + fieldname);
                PicklistCache[entityname + fieldname] = this.GetMutliSelectValueKeys(entityname, fieldname);
            }

            // loop through values from delimited string
            foreach (var value in optionList)
            {
                if (!string.IsNullOrEmpty(value.Trim()))
                {
                    if (PicklistCache[entityname + fieldname].ContainsKey(value.ToLower())) // Found in cache
                    {
                        options.Add(new OptionSetValue(PicklistCache[entityname + fieldname][value.Trim().ToLower()]));
                    }
                    else
                    {
                        if (AddIfNotFound)
                        {
                            intval = AddOptionSetOption(entityname, fieldname, value); // Add to CRM and return value
                            PicklistCache[entityname + fieldname].Add(value.ToLower(), intval); // Add to cache
                            options.Add(new OptionSetValue(intval)); // Add to collection which will set the value for the record
                        }
                    }
                }
            }

            if (options.Count > 0)
                return options;
            else
            {
                Logger.Debug("No Multi Select Option Set Found for field |" + fieldname + ":" + val + "|");
                return null;
            }
        }

        public OptionSetValue GetOptionSetValueViaCache(string entityname, string fieldname, string val, string globalOptionSet, bool AddIfNotFound = false)
        {
            val = val.Trim();
            if (string.IsNullOrEmpty(val))
            {
                val = "N/A";
            }
            if (!PicklistCache.ContainsKey(entityname + fieldname)) // cache is built
            {
                Logger.Info("Building OptionSet cache: " + entityname + fieldname);
                PicklistCache[entityname + fieldname] = this.GetPicklistValueKeys(entityname, fieldname);
            }

            if (PicklistCache[entityname + fieldname].ContainsKey(val.ToLower()))
            {
                return new OptionSetValue(PicklistCache[entityname + fieldname][val.Trim().ToLower()]);
            }
            if (AddIfNotFound)
            {
                int intval;
                if (String.IsNullOrEmpty(globalOptionSet))
                    intval = AddOptionSetOption(entityname, fieldname, val);
                else
                {
                    int globalValue = PicklistCache[entityname + fieldname].Select(temp => temp.Value).Concat(new[] { 100000000 }).Max();
                    globalValue++;
                    intval = globalValue;
                    AddGlobalOptionSetOption(globalOptionSet, val, globalValue);
                }
                PicklistCache[entityname + fieldname].Add(val.ToLower(), intval);

                return new OptionSetValue(intval);
            }

            Logger.Debug("No Picklist Found for field |" + fieldname + ":" + val + "|");
            return null;
        }


        public OptionSetValue GetOptionSetIntValueViaCache(string entityname, string fieldname, int val, bool AddIfNotFound = false)
        {
            if (!PicklistCache.ContainsKey(entityname + fieldname)) // cache is built
            {
                Logger.Info("Building  OptionSet cache: " + entityname + fieldname);
                PicklistCache[entityname + fieldname] = this.GetPicklistValueKeys(entityname, fieldname);
            }

            if (PicklistCache[entityname + fieldname].ContainsValue(val))
            {
                return new OptionSetValue(val);
            }

            Logger.Debug("No Picklist Found for field |" + fieldname + ":" + val + "|");
            return null;

        }
        public Dictionary<string, string> GetOrgs(string ServerAddress, string UserName, string Password)
        {
            return new ServerConnection().GetOrgs(ServerAddress, UserName, Password);
        }

        [Obsolete("orgname is no longer used, include full CRM HTTP path for servername")]
        public void Login(string servername, string orgname, string username, string password, bool x509cert)
        {
            Login(servername, orgname, username, password, false, false);
        }

        [Obsolete("orgname is no longer used, include full CRM HTTP path for servername")]
        public void Login(string servername, string orgname, string username, string password)
        {
            Login(servername, orgname, username, password, false, false);
        }

        public void Login(string servername, string username, string password)
        {
            Login(servername, null, username, password, false, false);
        }

        public void Login(string servername, string orgname, string username, string password, bool x509cert, bool tls12)
        {
            this._defaultPrefix = "";
            string key = username.Replace("@", "");
            if (!IsProxyInCache(key))
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11;

                if (username.Contains(".com"))
                    this.Service = Connect.GetOrganizationService(username, password, servername);
                else
                    this.Service = Connect.GetOrganizationServiceClientSecret(username, password, servername);

                //add the newly logined service to the cache
                HttpRuntime.Cache.Add(key, this.Service, null, System.Web.Caching.Cache.NoAbsoluteExpiration,
                                      new TimeSpan(0, 5, 0), System.Web.Caching.CacheItemPriority.Normal, null);

                _loggedin = true;
            }
            _loggedin = true;

        }

        //public void Login(string servername, string orgname, string username, string password, bool x509cert, bool tls12)
        //{
        //    this._defaultPrefix = ""; // reset this cache value
        //    string key = orgname + username.Replace("@", "");

        //    if (!IsProxyInCache(key))
        //    {
        //        Logger.Info("Authenticating (CRM)");
        //        this._servername = servername;
        //        this._orgname = orgname;
        //        ServerConnection serverConnect = new ServerConnection();
        //        ServerConnection.Configuration config = null;
        //        do
        //        {
        //            try
        //            {
        //                if (x509cert)
        //                {
        //                    ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
        //                }

        //                //TODO: Fix#22 - This was a quick fix to resolve connectivity issue occuring on line 68 of the serviceproxies.cs.
        //                //      Should we extend this ability? 
        //                //      SecurityProtocolType Enumeration
        //                //      https://msdn.microsoft.com/en-us/library/system.net.securityprotocoltype(v=vs.110).aspx
        //                //      (we mmay also want to see if updating CRM SDK cs files fixes this).

        //                //if (tls12)
        //                //{
        //                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        //                //}

        //                config = serverConnect.GetServerConfiguration(servername, username, password, orgname);

        //                this._serviceProxy = new ManagedTokenOrganizationServiceProxy(config.OrganizationUri, config.HomeRealmUri, config.Credentials, config.DeviceCredentials);

        //                //add the newly logined service to the cache
        //                HttpRuntime.Cache.Add(key, this._serviceProxy, null, System.Web.Caching.Cache.NoAbsoluteExpiration,
        //                                      new TimeSpan(0, 5, 0), System.Web.Caching.CacheItemPriority.Normal, null);

        //                _loggedin = true;
        //            }
        //            catch (Exception ex)
        //            {
        //                Logger.Info("Error connecting: " + ex.Message);
        //            }

        //        } while (config != null && config.DeviceCredentials == null);
        //    }
        //}

        public EntityCollection GetEntityCollectionbyAttribute(string Entity, string Value, string TargetAttribute)
        {
            try
            {
                ConditionExpression conditionPrincipal = new ConditionExpression();

                //Sets the ConditionExpressions Properties so that the condition
                // is true when the accountnumber of the account Equals the principalID
                conditionPrincipal.AttributeName = TargetAttribute;
                conditionPrincipal.Operator = ConditionOperator.Equal;
                conditionPrincipal.Values.Add(new object[1]);
                conditionPrincipal.Values[0] = Value;

                //Create the FilterExpression
                FilterExpression filterPrincipal = new FilterExpression();

                //Set the FilterExpression's Properties
                filterPrincipal.FilterOperator = LogicalOperator.And;
                filterPrincipal.Conditions.Add(conditionPrincipal);

                //Create the Query Expression
                QueryExpression queryPrincipal = new QueryExpression();

                //set the QueryExpressions Properties
                queryPrincipal.EntityName = Entity;
                queryPrincipal.ColumnSet.AllColumns = true;
                queryPrincipal.Criteria = filterPrincipal;

                return this.Service.RetrieveMultiple(queryPrincipal);
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Error in GetEntityCollectionByAttribute");
                throw new Exception("Error in GetEntityCollectionByAttribute" + ex.ToString());
            }
        }
        public Guid GetEntityIDbyAttribute(string Entity, string SearchValue, string SearchAttribute, bool CacheResults = true, bool SearchCRMIfNotInCache = true)
        {
            if (this.EntityCache.ContainsKey(Entity + SearchAttribute))
            {
                Logger.Debug("Contains Key: " + SearchValue + " - " + EntityCache[Entity + SearchAttribute].ContainsKey(SearchValue));
                Guid temp = Guid.Empty;
                if ((SearchValue.Contains("-")) && Guid.TryParse(SearchValue, out temp))
                {
                    if (this.EntityCache[Entity + SearchAttribute].ContainsKey("{" + temp.ToString() + "}"))//SearchValue + "}"))
                    {
                        return this.EntityCache[Entity + SearchAttribute]["{" + temp.ToString() + "}"];//SearchValue + "}"];
                    }
                    else if (this.EntityCache[Entity + SearchAttribute].ContainsKey(SearchValue))
                    {
                        return this.EntityCache[Entity + SearchAttribute][SearchValue];
                    }
                    else if (this.EntityCache[Entity + SearchAttribute].ContainsKey( temp.ToString() ))//SearchValue + "}"))
                    {
                        return this.EntityCache[Entity + SearchAttribute][ temp.ToString() ];//SearchValue + "}"];
                    }
                    
                }
                else if (this.EntityCache[Entity + SearchAttribute].ContainsKey(SearchValue))
                {
                    return this.EntityCache[Entity + SearchAttribute][SearchValue];
                }
            }
            else if (CacheResults) this.EntityCache[Entity + SearchAttribute] = new Dictionary<string, Guid>(StringComparer.OrdinalIgnoreCase);

            if (!SearchCRMIfNotInCache)
            {
                return Guid.Empty;
            }

            try
            {
                ConditionExpression conditionPrincipal = new ConditionExpression();

                //Sets the ConditionExpressions Properties so that the condition
                // is true when the accountnumber of the account Equals the principalID
                conditionPrincipal.AttributeName = SearchAttribute;
                conditionPrincipal.Operator = ConditionOperator.Equal;
                conditionPrincipal.Values.Add(new object[1]);
                conditionPrincipal.Values[0] = SearchValue;

                //Create the FilterExpression
                FilterExpression filterPrincipal = new FilterExpression();

                //Set the FilterExpression's Properties
                filterPrincipal.FilterOperator = LogicalOperator.And;
                filterPrincipal.Conditions.Add(conditionPrincipal);

                //Create the Query Expression
                QueryExpression queryPrincipal = new QueryExpression();

                //set the QueryExpressions Properties
                queryPrincipal.EntityName = Entity;
                queryPrincipal.ColumnSet = new ColumnSet(new string[] { this.GetPrimaryKey(Entity) });
                queryPrincipal.Criteria = filterPrincipal;

                EntityCollection e = this.Service.RetrieveMultiple(queryPrincipal);
                if (e != null && e.Entities.Count > 0)
                {
                    if (CacheResults) this.EntityCache[Entity + SearchAttribute][SearchValue] = e[0].Id;
                    return e[0].Id;
                }
                return Guid.Empty;
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Error in GetEntityIDByAttribute");
                throw new Exception("Error in GetEntityIDByAttribute" + ex.ToString());
            }

        }
        public Guid GetSecurityRoleWithBU(EntityReference BU, string RoleName, string SearchAttribute = "name")
        {
            ConditionExpression conditionPrincipal = new ConditionExpression();
            conditionPrincipal.AttributeName = SearchAttribute;
            conditionPrincipal.Operator = ConditionOperator.Equal;
            conditionPrincipal.Values.Add(new object[1]);
            conditionPrincipal.Values[0] = RoleName;


            ConditionExpression conditionPrincipal2 = new ConditionExpression();
            conditionPrincipal2.AttributeName = "businessunitid";
            conditionPrincipal2.Operator = ConditionOperator.Equal;
            conditionPrincipal2.Values.Add(new object[1]);
            conditionPrincipal2.Values[0] = BU.Id;


            //Create the FilterExpression
            FilterExpression filterPrincipal = new FilterExpression();

            //Set the FilterExpression's Properties
            filterPrincipal.FilterOperator = LogicalOperator.And;
            filterPrincipal.Conditions.Add(conditionPrincipal);
            filterPrincipal.Conditions.Add(conditionPrincipal2);


            //Create the Query Expression
            QueryExpression queryPrincipal = new QueryExpression();

            //set the QueryExpressions Properties
            queryPrincipal.EntityName = "role";
            queryPrincipal.ColumnSet = new ColumnSet(new string[] { "roleid" });
            queryPrincipal.Criteria = filterPrincipal;

            EntityCollection e = this.Service.RetrieveMultiple(queryPrincipal);
            if (e != null && e.Entities.Count > 0)
            {
                if (e[0].Attributes.ContainsKey("roleid"))
                {
                    return (Guid)e[0]["roleid"];
                }
                else return Guid.Empty;
            }
            else return Guid.Empty;
        }

        public Guid GetEntityIDRelatedbyAttribute(string Entity, string SearchValue, string SearchAttribute, string ReturnedAttribute)//example: return the ownerid of the account with the accountnumber of X
        {
            try
            {
                ConditionExpression conditionPrincipal = new ConditionExpression();

                //Sets the ConditionExpressions Properties so that the condition
                // is true when the accountnumber of the account Equals the principalID
                conditionPrincipal.AttributeName = SearchAttribute;
                conditionPrincipal.Operator = ConditionOperator.Equal;
                conditionPrincipal.Values.Add(new object[1]);
                conditionPrincipal.Values[0] = SearchValue;

                //Create the FilterExpression
                FilterExpression filterPrincipal = new FilterExpression();

                //Set the FilterExpression's Properties
                filterPrincipal.FilterOperator = LogicalOperator.And;
                filterPrincipal.Conditions.Add(conditionPrincipal);

                //Create the Query Expression
                QueryExpression queryPrincipal = new QueryExpression();

                //set the QueryExpressions Properties
                queryPrincipal.EntityName = Entity;
                queryPrincipal.ColumnSet = new ColumnSet(new string[] { ReturnedAttribute });
                queryPrincipal.Criteria = filterPrincipal;

                EntityCollection e = this.Service.RetrieveMultiple(queryPrincipal);
                if (e != null && e.Entities.Count > 0)
                {
                    if (e[0].Attributes.ContainsKey(ReturnedAttribute))
                    {
                        return ((EntityReference)e[0].Attributes[ReturnedAttribute]).Id;
                    }
                    else return Guid.Empty;
                }
                else return Guid.Empty;
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Error in GetEntityIDByAttribute");
                throw new Exception("Error in GetEntityIDByAttribute" + ex.ToString());
            }
        }
        public string GetEntityRelatedStringbyAttribute(string Entity, string SearchValue, string SearchAttribute, string ReturnedAttribute)
        {
            try
            {
                ConditionExpression conditionPrincipal = new ConditionExpression();

                //Sets the ConditionExpressions Properties so that the condition
                // is true when the accountnumber of the account Equals the principalID
                conditionPrincipal.AttributeName = SearchAttribute;
                conditionPrincipal.Operator = ConditionOperator.Equal;
                conditionPrincipal.Values.Add(new object[1]);
                conditionPrincipal.Values[0] = SearchValue;

                //Create the FilterExpression
                FilterExpression filterPrincipal = new FilterExpression();

                //Set the FilterExpression's Properties
                filterPrincipal.FilterOperator = LogicalOperator.And;
                filterPrincipal.Conditions.Add(conditionPrincipal);

                //Create the Query Expression
                QueryExpression queryPrincipal = new QueryExpression();

                //set the QueryExpressions Properties
                queryPrincipal.EntityName = Entity;
                queryPrincipal.ColumnSet = new ColumnSet(new string[] { ReturnedAttribute });
                queryPrincipal.Criteria = filterPrincipal;

                EntityCollection e = this.Service.RetrieveMultiple(queryPrincipal);
                if (e != null && e.Entities.Count > 0)
                {
                    if (e[0].Attributes.ContainsKey(ReturnedAttribute))
                    {
                        return ((string)e[0].Attributes[ReturnedAttribute]);
                    }
                    else return string.Empty;
                }
                else return string.Empty;
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Error in GetEntityIDByAttribute");
                throw new Exception("Error in GetEntityIDByAttribute" + ex.ToString());
            }
        }

        public EntityReference GetEntityReferenceByAttribute(string Entity, string SearchValue, string SearchAttribute, bool CacheResults = true, bool SearchCRMIfNotInCache = true)
        {
            return new EntityReference(Entity, GetEntityIDbyAttribute(Entity, SearchValue, SearchAttribute, CacheResults, SearchCRMIfNotInCache));
        }
        public Guid Create(Entity entity)
        {
            return this.Service.Create(entity);
        }

        public Guid Create(SystemUser entity)
        {
            return this.Service.Create(entity);
        }

        public void Update(Entity entity)
        {
            this.Service.Update(entity);
        }
        public void Delete(string entityName, Guid id)
        {
            this.Service.Delete(entityName, id);
        }
        public Guid CreateXml(Entity u)
        {
            return this.Service.Create(u);
        }

        public OrganizationResponse Execute(RetrieveAllEntitiesRequest request)
        {
            return this.Service.Execute(request);
        }
        public OrganizationResponse Execute(OrganizationRequest request)
        {
            return this.Service.Execute(request);
        }
        public SetStateResponse Execute(SetStateRequest request)
        {
            return (SetStateResponse)this.Service.Execute(request);
        }

        public Entity Retrieve(string p, Guid guid, Microsoft.Xrm.Sdk.Query.ColumnSet columnSet)
        {
            return this.Service.Retrieve(p, guid, columnSet);
        }

        public EntityCollection RetrieveMultiple(QueryExpression query)
        {
            return this.Service.RetrieveMultiple(query);
        }

        public OrganizationResponse RetrieveMultipleRequest2(FetchExpression query)
        {
            RetrieveMultipleRequest request = new RetrieveMultipleRequest();
            request.Query = query;

            return this.Service.Execute(request);
        }

        public EntityCollection RetrieveMultiple(FetchExpression query)
        {
            return this.Service.RetrieveMultiple(query);
        }

        public string GetMetaTimestampHash()
        {
            RetrieveTimestampRequest req = new RetrieveTimestampRequest();
            RetrieveTimestampResponse resp = (RetrieveTimestampResponse)this.Service.Execute(req);
            return resp.Timestamp;
        }

        public void AllowEarlyBinding()
        {
            //if (this.Service != null)
            //{
            //    this.Service.ServiceConfiguration.CurrentServiceEndpoint.Behaviors.Add(new ProxyTypesBehavior());
            //}
        }

        public OrganizationRequest GetRequestUpdateRecordStatus(Guid recordid, string entityname, int statecode, int statuscode)
        {
            if (entityname.ToLower() == "opportunity")
            {
                return GetRequestUpdateRecordStatusOpportunity(recordid, statecode, statuscode);
            }
            if (entityname.ToLower() == "quote")
            {
                return GetRequestUpdateRecordStatusQuote(recordid, statecode, statuscode);
            }
            if (entityname.ToLower() == "salesorder")
            {
                return GetRequestUpdateRecordStatusSalesOrder(recordid, statecode, statuscode);
            }
            else if (entityname.ToLower() == "incident")
            {
                return GetRequestUpdateRecordStatusIncident(recordid, statecode, statuscode);
            }
            else
            {
                SetStateRequest req = new SetStateRequest();
                req.EntityMoniker = new EntityReference(entityname, recordid);
                req.State = new OptionSetValue(statecode);
                req.Status = new OptionSetValue(statuscode);

                return req;
            }
        }
        public bool updateRecordStatus(Guid recordid, string entityname, int statecode, int statuscode)
        {

            try
            {
                OrganizationRequest req = GetRequestUpdateRecordStatus(recordid, entityname, statecode, statuscode);
                this.Execute(req);
                return true;
            }
            catch (Exception ex) { Logger.Error(ex, "Error setting state&status  of " + statecode + " & " + statuscode + " for " + entityname); return false; }
        }

        private Func<string, Guid, Entity> createOpportunityClose = (subject, oGuid) =>
        {
            Entity opportunityClose = new Entity("opportunityclose");
            opportunityClose.Attributes.Add("opportunityid", new EntityReference("opportunity", oGuid));
            opportunityClose.Attributes.Add("subject", subject);
            return opportunityClose;
        };
        private Func<string, Guid, Entity> createQuoteClose = (subject, oGuid) =>
        {
            Entity close = new Entity("quoteclose");
            close.Attributes.Add("quoteid", new EntityReference("quote", oGuid));
            close.Attributes.Add("subject", subject);
            return close;
        };
        private Func<string, Guid, Entity> createOrderClose = (subject, oGuid) =>
        {
            Entity close = new Entity("orderclose");
            close.Attributes.Add("salesorderid", new EntityReference("salesorder", oGuid));
            close.Attributes.Add("subject", subject);
            return close;
        };

        public OrganizationRequest GetRequestUpdateRecordStatusOpportunity(Guid opportunityID, int state, int status)
        {
            // state - 0: Open, 1: Won, 2: Lost  
            OrganizationRequest req = null;

            if (state == 0)

                req = new SetStateRequest()
                {
                    EntityMoniker = new EntityReference("opportunity", opportunityID),
                    State = new OptionSetValue(state),
                    Status = new OptionSetValue(status)
                };
            else if (state == 1)
                req = new WinOpportunityRequest()
                {
                    OpportunityClose = createOpportunityClose("Won the opportunity!", opportunityID),
                    Status = new OptionSetValue(status),
                };
            else if (state == 2)
                req = new LoseOpportunityRequest()
                {
                    OpportunityClose = createOpportunityClose("Lost the opportunity!", opportunityID),
                    Status = new OptionSetValue(status)
                };

            return req;
        }
        public OrganizationRequest GetRequestUpdateRecordStatusQuote(Guid quoteID, int state, int status)
        {
            // state - 0: Open, 1: Won, 2: Lost  
            OrganizationRequest req = null;

            if (state == 0 || state == 1)
            {
                req = new SetStateRequest()
                {
                    EntityMoniker = new EntityReference("quote", quoteID),
                    State = new OptionSetValue(state),
                    Status = new OptionSetValue(status)//1:Open
                };
            }
            else if (state == 2)
                req = new WinQuoteRequest()
                {
                    QuoteClose = createQuoteClose("Won the Quote!", quoteID),
                    Status = new OptionSetValue(status), //2:In Progress, 3:Open, 4: Won
                };
            else if (state == 3)
                req = new CloseQuoteRequest()
                {
                    QuoteClose = createQuoteClose("Lost the Quote!", quoteID),
                    Status = new OptionSetValue(status) // 5:Lost, 6:Cancelled, 7:Revised
                };

            return req;
        }
        public OrganizationRequest GetRequestUpdateRecordStatusSalesOrder(Guid salesorderid, int state, int status)
        {
            // state - 0: Open, 1: Won, 2: Lost  
            OrganizationRequest req = null;

            if (state == 0 || state == 1)
            {
                req = new SetStateRequest()
                {
                    EntityMoniker = new EntityReference("salesorder", salesorderid),
                    State = new OptionSetValue(state),
                    Status = new OptionSetValue(status)//1:Open
                };
            }
            else if (state == 2)
                req = new CancelSalesOrderRequest()
                {
                    OrderClose = createOrderClose("Cancelled Order", salesorderid),
                    Status = new OptionSetValue(status), //2:In Progress, 3:Open, 4: Won
                };
            else if (state == 3)
                req = new FulfillSalesOrderRequest()
                {
                    OrderClose = createOrderClose("Fulfilled Order", salesorderid),
                    Status = new OptionSetValue(status) // 5:Lost, 6:Cancelled, 7:Revised
                };

            return req;
        }

        public OrganizationRequest GetRequestUpdateRecordStatusIncident(Guid incidentID, int state, int status)
        {
            // state - 0: Open, 1: Resolved, 2: Canceled  
            OrganizationRequest req = null;

            if (state == 0)
            {
                req = new SetStateRequest()
                {
                    EntityMoniker = new EntityReference("incident", incidentID),
                    State = new OptionSetValue(state),
                    Status = new OptionSetValue(status)
                };
            }
            else if (state == 1)
            {
                // Close this incidentid with the item
                Entity myCaseRes = new Entity("incidentresolution");
                myCaseRes["subject"] = "This Case is Resolved!";
                myCaseRes["incidentid"] = new EntityReference("incident", incidentID);

                req = new CloseIncidentRequest()
                {
                    IncidentResolution = myCaseRes,
                    Status = new OptionSetValue(status)
                };
            }
            else if (state == 2)
            {
                //// Close this incidentid with the item
                //Entity myCaseRes = new Entity("incidentresolution");
                //myCaseRes["subject"] = "This Case is Canceled!";
                //myCaseRes["incidentid"] = new EntityReference("incident",incidentID);

                //req = new CloseIncidentRequest()
                //{
                //    IncidentResolution = myCaseRes,
                //    Status = new OptionSetValue(status)
                //};
                req = new SetStateRequest()
                {
                    EntityMoniker = new EntityReference("incident", incidentID),
                    State = new OptionSetValue(state),
                    Status = new OptionSetValue(status)
                };
            }
            return req;
        }

        public bool updateRecordStatusOpportunity(Guid opportunityID, int state, int status)
        {
            // state - 0: Open, 1: Won, 2: Lost  
            OrganizationRequest req = GetRequestUpdateRecordStatusOpportunity(opportunityID, state, status);

            if (req != null)
            {
                this.Execute(req);
                return true;
            }
            else return false;
        }
        public AssociateRequest GetRequestAssignRoleToUser(Guid UserId, Guid RoleId)
        {
            AssociateRequest req = new AssociateRequest();
            req.RelatedEntities = new EntityReferenceCollection();
            req.RelatedEntities.Add(new EntityReference("systemuser", UserId));
            req.Relationship = new Relationship("systemuserroles_association");
            req.Target = new EntityReference("role", RoleId);

            return req;
        }
        public AssociateRequest GetRequestAssignRoleToTeam(Guid TeamId, Guid RoleId)
        {
            AssociateRequest req = new AssociateRequest();
            req.RelatedEntities = new EntityReferenceCollection();
            req.RelatedEntities.Add(new EntityReference("team", TeamId));
            req.Relationship = new Relationship("teamroles_association");
            req.Target = new EntityReference("role", RoleId);

            return req;
        }

        public bool AssignRoleToUser(Guid UserId, Guid RoleId)
        {
            try
            {
                this.Service.Associate(
                       SystemUser.EntityLogicalName,
                       UserId,
                       new Relationship("systemuserroles_association"),
                       new EntityReferenceCollection() { new EntityReference(Role.EntityLogicalName, RoleId) });
                return true;
            }
            catch {
                return false;
            }
        }

        public List<string> GetMyAssignedRoles()
        {
            string fetch = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'> <entity name='role'> <attribute name='name' /> <link-entity name='systemuserroles' from='roleid' to='roleid' visible='false' intersect='true'> <link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='aa'> <filter type='and'> <condition attribute='systemuserid' operator='eq-userid' /></filter></link-entity></link-entity></entity></fetch>";
            DataSet ds = this.RunXML(fetch);
            List<string> results = new List<string>();
            if (ds.Tables.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    string RoleName = dr["name"].ToString();
                    if (!results.Contains(RoleName)) results.Add(RoleName);
                }
            }

            return results;
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Crm.Sdk.Messages;
using System.Xml;
using System.IO;
using System.Data;
using ztLogging;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk;

namespace fsCore2016
{
    partial class ztCore2011
    {
        private int fetchRecordsPerPage = 5000;
        private int pageNumber = 1;
        private string pagingCookie = null;
        private string fetchPropertyDelimiter = "."; // see constructor where this gets set from .config or defaulted to .

        public string MoreRecords { get; private set; }

        public void SetFetchRecordsPerPage(int RecordsPerPage)
        {
            this.fetchRecordsPerPage = RecordsPerPage;
        }
        public void SetFetchPropertyDelimiter(string fetchPropertyDelimiter)
        {
            this.fetchPropertyDelimiter = fetchPropertyDelimiter;
        }
        public DateTime GetOrgAge()
        {
            string fetch = "<fetch distinct='false' mapping='logical' count='1'><entity name='report'><attribute name='modifiedon' /><order attribute='modifiedon' descending='false'/></entity></fetch>";

            Microsoft.Xrm.Sdk.EntityCollection ResultSet = _serviceProxy.RetrieveMultiple(new Microsoft.Xrm.Sdk.Query.FetchExpression(fetch));

            foreach (var c in ResultSet.Entities)
            {                
                object aggregate1 = c["modifiedon"];
                return Convert.ToDateTime(aggregate1);
            }
            return DateTime.MinValue;
        }
        public int GetUserCount()
        {
            return Convert.ToInt32(this.QuickAggregate("systemuser", "systemuserid", "count"));
        }
        public string QuickAggregate(string entity, string attribute, string aggOperator = "count")
        {
            string fetch = "<fetch distinct='false' mapping='logical' aggregate='true'><entity name='" + entity + "'><attribute name='" + attribute + "' aggregate='" + aggOperator + "' alias='aggValue'/></entity></fetch>";
            
            Microsoft.Xrm.Sdk.EntityCollection ResultSet = _serviceProxy.RetrieveMultiple(new Microsoft.Xrm.Sdk.Query.FetchExpression(fetch));

            foreach (var c in ResultSet.Entities)
            {
                Microsoft.Xrm.Sdk.AliasedValue aggregate1 = (Microsoft.Xrm.Sdk.AliasedValue)c["aggValue"];
                return Convert.ToString(aggregate1.Value.ToString());
            }
            return "";
        }
        public List<string> GetFetchColumnSet(string fetchxml)
        {
            List<string> results = new List<string>();
            string test;
            int oldpagesize = this.fetchRecordsPerPage;
            this.SetFetchRecordsPerPage(100);
            try
            {
                DataSet ds = this.RunXML(fetchxml, 1, out test);
                foreach (DataColumn dc in ds.Tables[0].Columns)
                {
                    results.Add(dc.ColumnName);
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex, "ERROR in GetFetchColumnSet");
            }
            this.SetFetchRecordsPerPage(oldpagesize);

            

            return results;
        }


        public string ExecuteFetch(string fetchXml)
        {
            return ExecuteFetch(fetchXml, false);
        }


        public DataTable DTExecuteSPDocFetch(string fetchXml)
        {
            int fetchCount = fetchRecordsPerPage;         // Set the number of records per page to retrieve.
            XmlDocument oResults = new XmlDocument(); // contains resultset from all pages

            while (true)
            {

                Microsoft.Xrm.Sdk.Query.FetchExpression query = new Microsoft.Xrm.Sdk.Query.FetchExpression(fetchXml);
                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest request = new RetrieveMultipleRequest();
                request.Query = query;

                RetrieveMultipleResponse resp = (RetrieveMultipleResponse)this.Service.Execute(request);

                // Create a dataset and datatable
                //DataSet results = new DataSet("Results");
                DataTable Table1 = new DataTable("Results");
                DataColumn column;
                DataRow workRow = null;

                foreach (Entity entity in resp.EntityCollection.Entities)
                {
                    //create the columns in the data table
                    foreach (KeyValuePair<String, Object> attribute in entity.Attributes)
                    {
                        if (attribute.Value != null)
                        {
                            column = new DataColumn();
                            switch (attribute.Value.GetType().Name)
                            {
                                case "AliasedValue":
                                    column.DataType = entity.GetAttributeValue<AliasedValue>(attribute.Key).Value.GetType();
                                    break;
                                case "EntityReference":
                                    column.DataType = entity.GetAttributeValue<EntityReference>(attribute.Key).Name.GetType();
                                    break;
                                case "OptionSetValue":
                                    column.DataType = entity.GetAttributeValue<OptionSetValue>(attribute.Key).Value.GetType();
                                    break;
                                default:
                                    column.DataType = attribute.Value.GetType();
                                    break;
                            }
                            column.ColumnName = attribute.Key;
                            Table1.Columns.Add(column);
                        }
                    }

                    break;
                }

               

                //add values
                foreach (Entity entity in resp.EntityCollection.Entities)
                {
                    workRow = Table1.NewRow();

                    foreach (KeyValuePair<String, Object> attribute in entity.Attributes)
                    {
                        if (attribute.Value != null && workRow != null)
                        {
                            switch (attribute.Value.GetType().Name)
                            {
                                case "AliasedValue":
                                    workRow[attribute.Key] = entity.GetAttributeValue<AliasedValue>(attribute.Key).Value;
                                    break;
                                case "EntityReference":
                                    workRow[attribute.Key] = entity.GetAttributeValue<EntityReference>(attribute.Key).Name;
                                    break;
                                case "OptionSetValue":
                                    workRow[attribute.Key] = entity.GetAttributeValue<OptionSetValue>(attribute.Key).Value;
                                    break;
                                default:
                                    workRow[attribute.Key] = attribute.Value;
                                    break;
                            }
                        }
                    }
                    Table1.Rows.Add(workRow);

                    //// only one row expected so exit

                }

                //results.Tables.Add(Table1);
                return Table1;
            }
        }
        


        public string ExecuteFetch(string fetchXml, bool firstPageOnly)
        {
            int fetchCount = fetchRecordsPerPage;         // Set the number of records per page to retrieve.
           pageNumber = 1;         // Initialize the page number.
            int initalPageNumber = pageNumber;
            pagingCookie = null;
           
            XmlDocument oResults = null; // contains resultset from all pages

            while (true)
            {
                string xml = string.Empty;
                if (fetchXml.Contains("top="))
                {
                    xml = CreateXml(fetchXml, pagingCookie, null, null);
                }
                else
                // Build fetchXml string with the placeholders.
                    xml = CreateXml(fetchXml, pagingCookie, pageNumber, fetchCount);

                    // Excute the fetch query and get the xml result.
                    ExecuteFetchRequest fetchRequest1 = new ExecuteFetchRequest
                    {
                        FetchXml = xml
                    };

                    string fetchResult = ((ExecuteFetchResponse)this.Service.Execute(fetchRequest1)).FetchXmlResult;

                    // Load the fetch result into XMLDocument to parse its cotents.
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(fetchResult);
                    

                // The morerecords attribute will return 1 if there are more records.
                MoreRecords = ExtractAttribute(doc, "morerecords");

                // The paging-cookie attribute holds the paging cookie to pass in the next query.
                pagingCookie = ExtractAttribute(doc, "paging-cookie");
                Logger.Debug(pagingCookie);

                    // Retrieve the result nodes.
                    XmlNodeList resultNodes = doc.DocumentElement.SelectNodes("result");

                if (oResults == null)
                {
                    oResults = new XmlDocument();
                    oResults.LoadXml(doc.InnerXml);
                }
                else
                {
                    XmlNodeList oNodes = doc.SelectNodes("/resultset/result");
                    XmlNode oResultsetNode = oResults.SelectSingleNode("/resultset");
                    foreach (XmlNode oNode in oNodes)
                    {
                        XmlNode oNewNode = oResults.ImportNode(oNode, true);
                        oResultsetNode.AppendChild(oNewNode);
                    }
                }


               if (MoreRecords != null && MoreRecords == "1" && !firstPageOnly) // Check for morerecords, if it returns 1.
                {
                    pageNumber++; // Increment the page number to retrieve the next page.
                }
                else
                {
                    pageNumber++;
                    break; // If no more records in the result nodes, exit the loop.
                }
            }
            return oResults.InnerXml; // return the combined XML
        }
        public string ExecuteFetchPaged(string fetchXml, int pageNumber, out string NewCookie, string pagingCookie = null, int fetchCount = 5000)
        {
            //int fetchCount = 5000;         // Set the number of records per page to retrieve.
            XmlDocument oResults = new XmlDocument(); // contains resultset from all pages
            // Build fetchXml string with the placeholders.
            string xml = CreateXml(fetchXml, pagingCookie, pageNumber, fetchCount);

            // Excute the fetch query and get the xml result.
            ExecuteFetchRequest fetchRequest1 = new ExecuteFetchRequest
            {
                FetchXml = xml
            };

            string fetchResult = ((ExecuteFetchResponse)this.Service.Execute(fetchRequest1)).FetchXmlResult;

            // Load the fetch result into XMLDocument to parse its cotents.
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(fetchResult);

            // The morerecords attribute will return 1 if there are more records.
            string moreRecords = ExtractAttribute(doc, "morerecords");

            // The paging-cookie attribute holds the paging cookie to pass in the next query.
            pagingCookie = ExtractAttribute(doc, "paging-cookie");

            // Retrieve the result nodes.
            XmlNodeList resultNodes = doc.DocumentElement.SelectNodes("result");

            oResults.LoadXml(doc.InnerXml);

            if (moreRecords != null && moreRecords == "1") // Check for morerecords, if it returns 1.
            {
                pageNumber++; // Increment the page number to retrieve the next page.
                NewCookie = pagingCookie;
            }
            else NewCookie = null;
            return oResults.InnerXml; // return the combined XML
        }

        public DataSet RunXML(string fetchXml)
        {
            DataSet ds = new DataSet();
            ds.Tables.Add(this.DTRunXML(fetchXml, new Dictionary<string, string>()));

            return ds;

        }
        public DataSet RunXML(string fetchXml, int pageNumber, out string NewCookie, string pagingCookie = null, int fetchCount = 5000)
        {
            DataSet ds = new DataSet();
            ds.Tables.Add(this.DTRunXML(fetchXml, new Dictionary<string, string>(), pageNumber, out NewCookie, pagingCookie, fetchCount));

            return ds;

        }
        public DataTable DTRunXML(string fetchXml, Dictionary<string, string> fieldTypes)
        {
            XmlDocument Results = new XmlDocument();
            Results.LoadXml(this.ExecuteFetch(fetchXml, false));
            Logger.Debug(fetchXml);
            DataTable dt = new DataTable("results");

            foreach (string fieldname in fieldTypes.Keys)
            {
                if (!dt.Columns.Contains(fieldname.Replace(".", this.fetchPropertyDelimiter)))
                {
                    dt.Columns.Add(fieldname.Replace(".", this.fetchPropertyDelimiter), Type.GetType(fieldTypes[fieldname.Replace(".", this.fetchPropertyDelimiter)]));
                }
            }

            //First pass through the result XML is to find the columns for the dataset 
            foreach (XmlElement result in Results.FirstChild)
            {
                foreach (XmlElement field in result)
                {
                    if (!dt.Columns.Contains(field.Name.Replace(".", this.fetchPropertyDelimiter)))
                    {
                        dt.Columns.Add(field.Name.Replace(".", this.fetchPropertyDelimiter), Type.GetType("System.String"));

                        if ((field.Attributes["name"] != null) && !dt.Columns.Contains(field.Name.Replace(".", this.fetchPropertyDelimiter) + this.fetchPropertyDelimiter + "name"))
                        {
                            dt.Columns.Add(field.Name.Replace(".", this.fetchPropertyDelimiter) + this.fetchPropertyDelimiter + "name", Type.GetType("System.String"));
                        }
                    }
                }
            }

            //Second pass Through the result XML is to fill out the data rows 
            foreach (XmlElement result in Results.FirstChild)
            {
                DataRow dr = dt.NewRow();
                foreach (XmlElement field in result)
                {
                    dr[field.Name.Replace(".", this.fetchPropertyDelimiter)] = field.InnerText;

                    if (field.Attributes["name"] != null)
                    {
                        if (!dt.Columns.Contains(field.Name.Replace(".", this.fetchPropertyDelimiter) + this.fetchPropertyDelimiter + "name"))
                        {
                            dt.Columns.Add(field.Name.Replace(".", this.fetchPropertyDelimiter) + this.fetchPropertyDelimiter + "name", Type.GetType("System.String"));
                        }
                        dr[field.Name.Replace(".", this.fetchPropertyDelimiter) + this.fetchPropertyDelimiter + "name"] = field.Attributes["name"].InnerText;
                    }
                }
                dt.Rows.Add(dr);
            }
            return dt;
        }
        public DataTable DTRunXML(string fetchXml, Dictionary<string, string> fieldTypes, int pageNumber, out string NewCookie, string pagingCookie = null, int fetchCount = 5000)
        {
            XmlDocument Results = new XmlDocument();
            Results.LoadXml(this.ExecuteFetchPaged(fetchXml, pageNumber, out NewCookie, pagingCookie, fetchCount));

            DataTable dt = new DataTable("results");

            foreach (string fieldname in fieldTypes.Keys)
            {
                if (!dt.Columns.Contains(fieldname.Replace(".", this.fetchPropertyDelimiter)))
                {
                    dt.Columns.Add(fieldname.Replace(".", this.fetchPropertyDelimiter), Type.GetType(fieldTypes[fieldname.Replace(".", this.fetchPropertyDelimiter)]));
                }
            }

            //First pass through the result XML is to find the columns for the dataset 
            foreach (XmlElement result in Results.FirstChild)
            {
                foreach (XmlElement field in result)
                {
                    if (!dt.Columns.Contains(field.Name.Replace(".", this.fetchPropertyDelimiter)))
                    {
                        dt.Columns.Add(field.Name.Replace(".", this.fetchPropertyDelimiter), Type.GetType("System.String"));

                        if ((field.Attributes["name"] != null) && !dt.Columns.Contains(field.Name.Replace(".", this.fetchPropertyDelimiter) + this.fetchPropertyDelimiter + "name"))
                        {
                            dt.Columns.Add(field.Name.Replace(".", this.fetchPropertyDelimiter) + this.fetchPropertyDelimiter + "name", Type.GetType("System.String"));
                        }
                    }
                }
            }

            //Second pass Through the result XML is to fill out the data rows 
            foreach (XmlElement result in Results.FirstChild)
            {
                DataRow dr = dt.NewRow();
                foreach (XmlElement field in result)
                {
                    dr[field.Name.Replace(".", this.fetchPropertyDelimiter)] = field.InnerText;

                    if (field.Attributes["name"] != null)
                    {
                        if (!dt.Columns.Contains(field.Name.Replace(".", this.fetchPropertyDelimiter) + this.fetchPropertyDelimiter + "name"))
                        {
                            dt.Columns.Add(field.Name.Replace(".", this.fetchPropertyDelimiter) + this.fetchPropertyDelimiter + "name", Type.GetType("System.String"));
                        }
                        dr[field.Name.Replace(".", this.fetchPropertyDelimiter) + this.fetchPropertyDelimiter + "name"] = field.Attributes["name"].InnerText;
                    }
                }
                dt.Rows.Add(dr);
            }
            return dt;
        }
        public int FetchCountRecords(string fetchxml)
        {
            try
            {
                int count = 0;
                int Page = 0;
                string Cookie = null;
                while (true)
                {
                    Page++;
                    DataSet dsData = this.RunXML(fetchxml, Page, out Cookie, Cookie);
                    count += dsData.Tables[0].Rows.Count;

                    if (Cookie == null) break;
                }

                return count;
            }
            catch (Exception Ex)
            {
                throw new Exception("ERROR: Cannot FetchCountRecords: " + Ex.ToString());
            }
        }
        #region XML Stuff
        public string ExtractNodeValue(XmlNode parentNode, string name)
        {
            XmlNode childNode = parentNode.SelectSingleNode(name);

            if (null == childNode)
            {
                return null;
            }
            return childNode.InnerText;
        }
        public string ExtractAttribute(XmlDocument doc, string name)
        {
            XmlAttributeCollection attrs = doc.DocumentElement.Attributes;
            XmlAttribute attr = (XmlAttribute)attrs.GetNamedItem(name);
            if (null == attr)
            {
                return null;
            }
            return attr.Value;
        }
        public string CreateXml(string xml, string cookie, int? page, int? count)
        {
            StringReader stringReader = new StringReader(xml);
            XmlTextReader reader = new XmlTextReader(stringReader);

            // Load document
            XmlDocument doc = new XmlDocument();
            doc.Load(reader);

            return CreateXml(doc, cookie, page, count);
        }
        public string CreateXml(XmlDocument doc, string cookie, int? page, int? count)
        {
            XmlAttributeCollection attrs = doc.DocumentElement.Attributes;

            if (cookie != null)
            {
                XmlAttribute pagingAttr = doc.CreateAttribute("paging-cookie");
                pagingAttr.Value = cookie;
                attrs.Append(pagingAttr);
            }
            if (page != null)
            {
                XmlAttribute pageAttr = doc.CreateAttribute("page");
                pageAttr.Value = System.Convert.ToString(page);
                attrs.Append(pageAttr);
            }

            if (count != null)
            {
                XmlAttribute countAttr = doc.CreateAttribute("count");
                countAttr.Value = System.Convert.ToString(count);
                attrs.Append(countAttr);
            }

            StringBuilder sb = new StringBuilder(1024);
            StringWriter stringWriter = new StringWriter(sb);

            XmlTextWriter writer = new XmlTextWriter(stringWriter);
            doc.WriteTo(writer);
            writer.Close();

            return sb.ToString();
        }
        #endregion XML Stuff
    }
}

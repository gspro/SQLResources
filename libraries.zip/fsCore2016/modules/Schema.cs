﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using LumenWorks.Framework.IO.Csv;
using System.IO;
using System.Configuration;
using Microsoft.Xrm.Sdk.Metadata.Query;
using Microsoft.Xrm.Sdk.Query;
using ztLogging;

namespace fsCore2016
{
    public partial class ztCore2011
    {
        private SortedDictionary<string, SortedDictionary<string, EntitySummary>> _SchemaCache = new SortedDictionary<string, SortedDictionary<string, EntitySummary>>();

        public SortedDictionary<string, SortedDictionary<string, EntitySummary>> FilteredSchemaCache
        {
            get
            {
                if (_SchemaCache.Count == 0)
                    this.GetFilteredSchemaCache(ConfigurationManager.AppSettings["CONFIG_SkipEntities"]);
                return this._SchemaCache;
            }
        }
        public SortedDictionary<string, SortedDictionary<string, EntitySummary>> SchemaCache
        {
            get
            {
                if (_SchemaCache.Count == 0) 
                    this.CacheSchemaFromWherever(ConfigurationManager.AppSettings["CONFIG_SkipEntities"]);
                return this._SchemaCache;
            }
        }
        public void ClearCache()
        {
            _SchemaCache.Clear();
        }
        public SortedDictionary<string, SortedDictionary<string, EntitySummary>> SchemaCacheOffline
        {
            get
            {
                if (_SchemaCache.Count == 0) this.CacheSchemaFromFile();
                return this._SchemaCache;
            }
        }
        private string _SchemaCacheFileName
        {
            get
            {
                string FileName = "SchemaCache-" + this._servername + this._orgname;
                string pattern = "[^A-Za-z0-9]";
                string replacement = "-";
                return System.Text.RegularExpressions.Regex.Replace(FileName, pattern, replacement) + ".csv";

            }
        }
        public string SchemaCacheFileName
        {
            get
            {
                return _SchemaCacheFileName;
            }
        }
        
        public SortedDictionary<string, EntitySummary> GetEntityScheme(string entityName)
        {
            SortedDictionary<string, EntitySummary> entityScheme = new SortedDictionary<string, EntitySummary>();

            RetrieveEntityResponse response;
            RetrieveEntityRequest entityRequest;

            try
            {
                // Retrieve the MetaData.
                try
                {
                    entityRequest = new RetrieveEntityRequest()
                    {
                        LogicalName = entityName,
                        EntityFilters = EntityFilters.Attributes,
                        RetrieveAsIfPublished = true,
                    };

                    response = (RetrieveEntityResponse)this.Execute(entityRequest); 
                }
                catch
                {
                    entityRequest = new RetrieveEntityRequest()
                    {
                        LogicalName = entityName,
                        EntityFilters = EntityFilters.Attributes,
                        RetrieveAsIfPublished = false,
                    };

                    response = (RetrieveEntityResponse)this.Execute(entityRequest);
                }
                
                EntityMetadata currentEntity = response.EntityMetadata;
                if (currentEntity.LogicalName == entityName)
                {
                    SortedDictionary<string, EntitySummary> Attributes = new SortedDictionary<string, EntitySummary>();
                    #region Attributes
                    foreach (AttributeMetadata currentAttribute in currentEntity.Attributes)
                    {
                        int maxlength = -1;
                        string AttributeName = currentAttribute.LogicalName;
                        string TargetEntity = "";
                        string DisplayName = "";
                        decimal? maxvalue = new decimal?();
                        decimal? minvalue = new decimal?();

                        try
                        {
                            DisplayName = currentAttribute.DisplayName.LocalizedLabels[0].Label;
                        }
                        catch { }

                        if (currentAttribute.AttributeOf == null)// Only write out main attributes.
                        {
                            string type = currentAttribute.AttributeType.Value.ToString();

                            if (type == "String")
                            {
                                StringAttributeMetadata str = (StringAttributeMetadata)currentAttribute;
                                maxlength = str.MaxLength.Value;
                            }
                            else if (type == "Memo")
                            {
                                MemoAttributeMetadata str = (MemoAttributeMetadata)currentAttribute;
                                maxlength = str.MaxLength.Value;
                            }
                            else if (type == "Lookup") // ?? what is this type ??
                            {
                                try
                                {
                                    TargetEntity = ((Microsoft.Xrm.Sdk.Metadata.LookupAttributeMetadata)currentAttribute).Targets[0];
                                }
                                catch { }
                            }
                            else if (type == "Integer")
                            {
                                IntegerAttributeMetadata intgr = (IntegerAttributeMetadata)currentAttribute;
                                maxvalue = intgr.MaxValue;
                                minvalue = intgr.MinValue;
                            }
                            else if (type == "Decimal")
                            {
                                DecimalAttributeMetadata dec = (DecimalAttributeMetadata)currentAttribute;
                                maxvalue = dec.MaxValue;
                                minvalue = dec.MinValue;
                            }
                            else if (type == "Double")
                            {
                                DoubleAttributeMetadata dbl = (DoubleAttributeMetadata)currentAttribute;
                                maxvalue = (decimal?)dbl.MaxValue;
                                minvalue = (decimal?)dbl.MinValue;
                            }


                            EntitySummary s = new EntitySummary();
                            s.AttributeSchemaName = AttributeName;
                            s.MaxLength = maxlength;
                            s.DataType = type;
                            s.EntityName = currentEntity.LogicalName;
                            s.RelatedEntityName = TargetEntity;
                            s.DisplayName = DisplayName;
                            s.PrimaryKey = currentEntity.PrimaryIdAttribute;
                            s.MaxValue = maxvalue;
                            s.MinValue = minvalue;

                            if (!Attributes.ContainsKey(AttributeName))
                            {
                                Attributes.Add(AttributeName, s);
                            }
                        }
                    }

                    entityScheme = Attributes;


                    #endregion

                }
            }
            catch (Exception ex) // Catch any service fault exceptions that Microsoft Dynamics CRM throws.
            {
                throw ex; // You can handle an exception here or pass it back to the calling method.
            }

            return entityScheme;
        }

        private void CacheSchemaFromServer(string SkipEntities = "")
        {
            try
            {
                Logger.Info("Caching CRM schema from server");

                RetrieveAllEntitiesRequest request;
                RetrieveAllEntitiesResponse response;

                // Retrieve the MetaData.
                try
                {
                    request = new RetrieveAllEntitiesRequest()
                    {
                        EntityFilters = EntityFilters.Attributes,
                        RetrieveAsIfPublished = true,
                    };

                    response = (RetrieveAllEntitiesResponse)this.Execute(request); 
                }
                catch
                {
                    request = new RetrieveAllEntitiesRequest()
                    {
                        EntityFilters = EntityFilters.Attributes,
                        RetrieveAsIfPublished = false,
                    };

                    response = (RetrieveAllEntitiesResponse)this.Execute(request); 
                }
                
                foreach (EntityMetadata currentEntity in response.EntityMetadata)
                {
                    
                    string tablename = currentEntity.LogicalName;
                    if (SkipEntities == null || !SkipEntities.Contains(";" + tablename + ";"))
                    {
                        SortedDictionary<string, EntitySummary> Attributes = new SortedDictionary<string, EntitySummary>();
                        #region Attributes
                        foreach (AttributeMetadata currentAttribute in currentEntity.Attributes)
                        {
                           
                            int maxlength = -1;
                            string AttributeName = currentAttribute.LogicalName;
                            string TargetEntity = "";
                            string DisplayName = "";
                            try
                            {
                                DisplayName = currentAttribute.DisplayName.LocalizedLabels[0].Label;
                            }
                            catch { }

                            if (currentAttribute.AttributeOf == null)// Only write out main attributes.
                            {
                                string type = currentAttribute.AttributeType.Value.ToString();

                                if (type == "String")
                                {
                                    StringAttributeMetadata str = (StringAttributeMetadata)currentAttribute;
                                    maxlength = str.MaxLength.Value;
                                }
                                else if (type == "Memo")
                                {
                                    MemoAttributeMetadata str = (MemoAttributeMetadata)currentAttribute;
                                    maxlength = str.MaxLength.Value;
                                }
                                else if (type == "Lookup") // ?? what is this type ??
                                {
                                    try
                                    {
                                        TargetEntity = ((Microsoft.Xrm.Sdk.Metadata.LookupAttributeMetadata)currentAttribute).Targets[0];
                                    }
                                    catch { }
                                }
                                EntitySummary s = new EntitySummary();
                                s.AttributeSchemaName = AttributeName;
                                s.MaxLength = maxlength;
                                s.DataType = type;
                                s.EntityName = tablename;
                                s.RelatedEntityName = TargetEntity;
                                s.DisplayName = DisplayName;
                                s.PrimaryKey = currentEntity.PrimaryIdAttribute;

                                if (!Attributes.ContainsKey(AttributeName))
                                {
                                    Attributes.Add(AttributeName, s);
                                }
                            }
                        }
                        if (!this._SchemaCache.ContainsKey(currentEntity.LogicalName))
                        {
                            this._SchemaCache.Add(currentEntity.LogicalName, Attributes);
                        }
                        #endregion
                    }
                }
            }
            catch (Exception ex) // Catch any service fault exceptions that Microsoft Dynamics CRM throws.
            {
               throw ex; // You can handle an exception here or pass it back to the calling method.
            }
        }

        private void CacheFilteredSchemaFromServer(string skipEntities = "")
        {
            try
            {
                Logger.Info("Caching CRM schema from server");
                if(skipEntities=="") skipEntities = "ConvertRule;CustomerRelationship;BulkOperation";

                string[] excludedEntities = !String.IsNullOrEmpty(skipEntities) ? skipEntities.Split(';') : null;
                SortedDictionary<string, EntitySummary> attributes = new SortedDictionary<string, EntitySummary>();

                //A filter expression to limit entities returned to non-intersect, user-owned entities not found in the list of excluded entities.
                MetadataFilterExpression EntityFilter = new MetadataFilterExpression(LogicalOperator.And);
                EntityFilter.Conditions.Add(new MetadataConditionExpression("IsIntersect", MetadataConditionOperator.Equals, false));
                EntityFilter.Conditions.Add(new MetadataConditionExpression("OwnershipType", MetadataConditionOperator.Equals, OwnershipTypes.UserOwned));
                EntityFilter.Conditions.Add(new MetadataConditionExpression("SchemaName", MetadataConditionOperator.NotIn, excludedEntities));

                //An entity query expression to combine the filter expressions and property expressions for the query.
                var entityQueryExpression = new EntityQueryExpression { Criteria = EntityFilter };

                //Retrieve the metadata for the query without a ClientVersionStamp
                var retrieveMetadataChangesRequest = new RetrieveMetadataChangesRequest
                {
                    Query = entityQueryExpression,
                    ClientVersionStamp = null
                };

                var response = (RetrieveMetadataChangesResponse)Service.Execute(retrieveMetadataChangesRequest);

                foreach (EntityMetadata currentEntity in response.EntityMetadata)
                {
                    foreach (var currentAttribute in currentEntity.Attributes)
                    {
                        attributes.Clear();
                        EntitySummary s = new EntitySummary();
                        s.AttributeSchemaName = currentAttribute.SchemaName;
                        string type = currentAttribute.AttributeType != null ? currentAttribute.AttributeType.Value.ToString() : string.Empty;

                        switch (type)
                        {
                            case "String":
                                s.MaxLength = ((StringAttributeMetadata)currentAttribute).MaxLength != null ? ((StringAttributeMetadata)currentAttribute).MaxLength.Value : 0;
                                break;
                            case "Memo":
                                s.MaxLength = ((MemoAttributeMetadata)currentAttribute).MaxLength != null ? ((MemoAttributeMetadata)currentAttribute).MaxLength.Value : 0;
                                break;
                            case "Lookup":
                                s.RelatedEntityName = ((LookupAttributeMetadata)currentAttribute).Targets != null && ((LookupAttributeMetadata)currentAttribute).Targets.Any() ? ((LookupAttributeMetadata)currentAttribute).Targets[0] : string.Empty;
                                break;
                        }
                        s.DataType = type;
                        s.EntityName = currentEntity.LogicalName;
                        s.DisplayName = currentAttribute.DisplayName != null && currentAttribute.DisplayName.LocalizedLabels.Count > 0 ? currentAttribute.DisplayName.LocalizedLabels[0].Label : string.Empty;
                        s.PrimaryKey = currentEntity.PrimaryIdAttribute;
                        //if(!attributes.ContainsKey(currentAttribute.SchemaName))
                            attributes.Add(currentAttribute.SchemaName, s);
                    }

                    if(!_SchemaCache.ContainsKey(currentEntity.LogicalName))
                        _SchemaCache.Add(currentEntity.LogicalName, attributes);
                }
                

            }
            catch (Exception ex) // Catch any service fault exceptions that Microsoft Dynamics CRM throws.
            {
                throw ex; // You can handle an exception here or pass it back to the calling method.
            }
        }
        public struct EntitySummary
        {
            public string EntityName;
            public string AttributeSchemaName;
            public int MaxLength;
            public string RelatedEntityName;
            public string DisplayName;
            public string DataType;
            public string PrimaryKey;
            public decimal? MaxValue;
            public decimal? MinValue;
        }
        public void WriteSchemaToFile(string FileName)
        {
            if (this._SchemaCache != null)
            {
                string FileContent = "EntityName,AttributeName,DataType,MaxLength,RelatedEntityName,DisplayName,PrimaryKey\r\n";
                foreach (string EntityName in this._SchemaCache.Keys)
                {
                    foreach (string AttributeName in this._SchemaCache[EntityName].Keys)
                    {
                        string DataType = this._SchemaCache[EntityName][AttributeName].DataType;
                        string DisplayName = this._SchemaCache[EntityName][AttributeName].DisplayName;
                        int MaxLength = this._SchemaCache[EntityName][AttributeName].MaxLength;
                        string RelatedEntityName = this._SchemaCache[EntityName][AttributeName].RelatedEntityName;
                        string PrimaryKey = this._SchemaCache[EntityName][AttributeName].PrimaryKey;

                        FileContent += EntityName + "," + AttributeName + "," + DataType + "," + MaxLength + "," + RelatedEntityName + "," + DisplayName.Trim() + "," + PrimaryKey + "\r\n";
                    }

                }
                System.IO.File.WriteAllText(FileName, FileContent);
            }
        }
        private void CacheSchemaFromFile(string FilePath = null)
        {
            if (FilePath == null) FilePath = this._SchemaCacheFileName;// default file path

            using (CsvReader csv = new CsvReader(new StreamReader(FilePath), true))
            {
                while (csv.ReadNextRecord())
                {
                    EntitySummary e = new EntitySummary();

                    string EntityName = csv["EntityName"];
                    string AttributeName = csv["AttributeName"];
                    string DataType = csv["DataType"];
                    string MaxLength = csv["MaxLength"];
                    string RelatedEntityName = csv["RelatedEntityName"];
                    string DisplayName = csv["DisplayName"];

                    try
                    {
                        e.PrimaryKey = csv["PrimaryKey"];
                    }
                    catch { } // PrimaryKey added in 4.5.x


                    e.EntityName = EntityName;
                    e.AttributeSchemaName = AttributeName;
                    e.DataType = DataType;
                    e.DisplayName = DisplayName;
                    e.MaxLength = Convert.ToInt32(MaxLength);
                    e.RelatedEntityName = RelatedEntityName;

                    if (!this._SchemaCache.ContainsKey(EntityName)) this._SchemaCache.Add(EntityName, new SortedDictionary<string, EntitySummary>());
                    if (!this._SchemaCache[EntityName].ContainsKey(AttributeName)) this._SchemaCache[EntityName].Add(AttributeName, e);
                }
            }
        }
        public void CacheSchemaFromWherever(string SkipEntities = "")
        {
            //bool getMetadata = !ConfigurationManager.AppSettings.AllKeys.Contains("CONFIG_RetreiveMetadata") || Convert.ToBoolean(ConfigurationManager.AppSettings["CONFIG_RetreiveMetadata"]);
            //getMetadata = false;
            if (File.Exists(this._SchemaCacheFileName) && File.Exists(this._SchemaCacheFileName + ".hash"))
            {
                string hash = this.GetMetaTimestampHash();

                string LastHash = File.ReadAllText(this._SchemaCacheFileName + ".hash");
                if (hash == LastHash)// the hash file locally matches the server so the schema has not changed - re-use from cache
                {
                    CacheSchemaFromFile(this._SchemaCacheFileName);
                }
                else // we have a hash file but it doesnt match the server so we need to re-cache from the server
                {
                    CacheSchemaFromServer(SkipEntities);
                    File.WriteAllText(this._SchemaCacheFileName + ".hash", hash);
                    try
                    {
                        WriteSchemaToFile(this._SchemaCacheFileName);
                    }
                    catch { } // if we can't write the file, no worries.
            
                }
            }
            else // cache files not found, get schema from server
            {
                string hash = this.GetMetaTimestampHash();
                CacheSchemaFromServer(SkipEntities);
                File.WriteAllText(this._SchemaCacheFileName + ".hash", hash);
                try
                {
                    WriteSchemaToFile(this._SchemaCacheFileName);
                }
                catch { } // if we can't write the file, no worries.
            }
        }
        public void RefreshSchemaCache()
        {
            string hash = this.GetMetaTimestampHash();
            Logger.Debug("Pulling new metadata");
            CacheSchemaFromServer(ConfigurationManager.AppSettings["CONFIG_SkipEntities"]);
            File.WriteAllText(this._SchemaCacheFileName + ".hash", hash);
            try
            {
                WriteSchemaToFile(this._SchemaCacheFileName);
            }
            catch { }
        }

        private void GetFilteredSchemaCache(string skipEntities)
        {
            bool getMetadata = Convert.ToBoolean(ConfigurationManager.AppSettings["CONFIG_RetreiveMetadata"]);

            if (File.Exists(this._SchemaCacheFileName) && File.Exists(this._SchemaCacheFileName + ".hash") && !getMetadata)
            {
                CacheSchemaFromFile(this._SchemaCacheFileName);
            }
            else
            {
                string hash = this.GetMetaTimestampHash();
                CacheFilteredSchemaFromServer(skipEntities);
                File.WriteAllText(this._SchemaCacheFileName + ".hash", hash);
                try
                {
                    WriteSchemaToFile(this._SchemaCacheFileName);
                }
                catch { } // if we can't write the file, no worries.
            }
        }
        public static Dictionary<string, string> SqlDataTypeMappings()
        {
            Dictionary<string, string> mapping = new Dictionary<string, string>();
            mapping.Add("BigInt", "bigint");
            mapping.Add("Boolean", "bit");
            mapping.Add("DateTime", "datetime");
            mapping.Add("Decimal", "decimal(16, 4)");
            mapping.Add("Double", "float");
            mapping.Add("EntityName", "nvarchar");
            mapping.Add("Integer", "int");
            mapping.Add("Customer", "uniqueidentifier");
            mapping.Add("Lookup", "uniqueidentifier");
            mapping.Add("Memo", "nvarchar(max)");
            mapping.Add("Money", "decimal(16, 4)");
            mapping.Add("Owner", "uniqueidentifier");
            mapping.Add("Picklist", "int");
            mapping.Add("State", "int");
            mapping.Add("Status", "int");
            mapping.Add("String", "nvarchar");
            mapping.Add("Uniqueidentifier", "uniqueidentifier");
            mapping.Add("Virtual", "nvarchar(max)");
            return mapping;
        }
    }
}

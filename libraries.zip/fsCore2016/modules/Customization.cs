﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Crm.Sdk;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

namespace fsCore2016
{
    public partial class ztCore2011
    {
        List<String> _globalPicklists = new List<string>();
        public Guid CreateAttributeString(string EntityName, string LogicalName, string DisplayName, int MaxLength = 100)
        {
            if (!DoesFieldExist(EntityName, LogicalName))
            {
                CreateAttributeRequest attrReq = new CreateAttributeRequest()
                {
                    Attribute = new StringAttributeMetadata()
                    {
                        LogicalName = LogicalName,
                        DisplayName = new Microsoft.Xrm.Sdk.Label(DisplayName, 1033),
                        SchemaName = LogicalName,
                        MaxLength = MaxLength,
                        RequiredLevel = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None),
                        IsSecured = false
                    },
                    EntityName = EntityName
                };

                // Execute the request.
                CreateAttributeResponse messageAttributeResponse = (CreateAttributeResponse)this.Service.Execute(attrReq);
                return messageAttributeResponse.AttributeId;
            }
            return Guid.Empty;
        }
        public Guid CreateAttributeInt(string EntityName, string LogicalName, string DisplayName, int MinValue = -1000000, int MaxValue = 1000000)
        {
            if (!DoesFieldExist(EntityName, LogicalName))
            {
                CreateAttributeRequest attrReq = new CreateAttributeRequest()
                {
                    Attribute = new IntegerAttributeMetadata()
                    {
                        LogicalName = LogicalName,
                        DisplayName = new Microsoft.Xrm.Sdk.Label(DisplayName, 1033),
                        SchemaName = LogicalName,
                        RequiredLevel = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None),
                        IsSecured = false,
                        MinValue = MinValue,
                        MaxValue = MaxValue,
                    },
                    EntityName = EntityName
                };

                // Execute the request.
                CreateAttributeResponse messageAttributeResponse = (CreateAttributeResponse)this.Service.Execute(attrReq);
                return messageAttributeResponse.AttributeId;
            }
            return Guid.Empty;
        }
        public Guid CreateAttributeMoney(string EntityName, string LogicalName, string DisplayName, int Precision = 4, int MinValue = -1000000, int MaxValue = 1000000)
        {
            if (!DoesFieldExist(EntityName, LogicalName))
            {
                CreateAttributeRequest attrReq = new CreateAttributeRequest()
                {
                    Attribute = new MoneyAttributeMetadata()
                    {
                        LogicalName = LogicalName,
                        DisplayName = new Microsoft.Xrm.Sdk.Label(DisplayName, 1033),
                        SchemaName = LogicalName,
                        RequiredLevel = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None),
                        IsSecured = false,
                        MinValue = MinValue,
                        MaxValue = MaxValue,
                        Precision = Precision
                    },
                    EntityName = EntityName
                };

                // Execute the request.
                CreateAttributeResponse messageAttributeResponse = (CreateAttributeResponse)this.Service.Execute(attrReq);
                return messageAttributeResponse.AttributeId;
            }
            return Guid.Empty;
        }
        public Guid CreateAttributeDecimal(string EntityName, string LogicalName, string DisplayName, int Precision = 4, int MinValue = -1000000, int MaxValue = 1000000)
        {
            if (!DoesFieldExist(EntityName, LogicalName))
            {
                CreateAttributeRequest attrReq = new CreateAttributeRequest()
                {
                    Attribute = new DecimalAttributeMetadata()
                    {
                        LogicalName = LogicalName,
                        DisplayName = new Microsoft.Xrm.Sdk.Label(DisplayName, 1033),
                        SchemaName = LogicalName,
                        RequiredLevel = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None),
                        IsSecured = false,
                        MinValue = MinValue,
                        MaxValue = MaxValue,
                        Precision = Precision
                    },
                    EntityName = EntityName
                };

                // Execute the request.
                CreateAttributeResponse messageAttributeResponse = (CreateAttributeResponse)this.Service.Execute(attrReq);
                return messageAttributeResponse.AttributeId;
            }
            return Guid.Empty;
        }
        public Guid CreateAttributeDouble(string EntityName, string LogicalName, string DisplayName, int Precision = 4, int MinValue = -1000000, int MaxValue = 1000000)
        {
            if (!DoesFieldExist(EntityName, LogicalName))
            {
                CreateAttributeRequest attrReq = new CreateAttributeRequest()
                {
                    Attribute = new DoubleAttributeMetadata()
                    {
                        LogicalName = LogicalName,
                        DisplayName = new Microsoft.Xrm.Sdk.Label(DisplayName, 1033),
                        SchemaName = LogicalName,
                        RequiredLevel = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None),
                        IsSecured = false,
                        MinValue = MinValue,
                        MaxValue = MaxValue,
                        Precision = Precision
                    },
                    EntityName = EntityName
                };

                // Execute the request.
                CreateAttributeResponse messageAttributeResponse = (CreateAttributeResponse)this.Service.Execute(attrReq);
                return messageAttributeResponse.AttributeId;
            }
            return Guid.Empty;

        }
        public Guid CreateAttributeDateTime(string EntityName, string LogicalName, string DisplayName, bool ShowTime = false)
        {
            if (!DoesFieldExist(EntityName, LogicalName))
            {
                CreateAttributeRequest attrReq = new CreateAttributeRequest()
                {
                    Attribute = new DateTimeAttributeMetadata()
                    {
                        LogicalName = LogicalName,
                        DisplayName = new Microsoft.Xrm.Sdk.Label(DisplayName, 1033),
                        SchemaName = LogicalName,
                        RequiredLevel = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None),
                        IsSecured = false,
                        Format = ShowTime ? DateTimeFormat.DateAndTime : DateTimeFormat.DateOnly

                    },
                    EntityName = EntityName
                };

                // Execute the request.
                CreateAttributeResponse messageAttributeResponse = (CreateAttributeResponse)this.Service.Execute(attrReq);
                return messageAttributeResponse.AttributeId;
            }
            return Guid.Empty;
        }
        public Guid CreateAttributeOptionSet(string EntityName, string LogicalName, string DisplayName, bool IsGlobal = false)
        {
            try
            {
                if (!DoesFieldExist(EntityName, LogicalName))
                {
                    CreateAttributeRequest attrReq = new CreateAttributeRequest()
                    {
                        Attribute = new PicklistAttributeMetadata()
                        {
                            LogicalName = LogicalName,
                            DisplayName = new Label(DisplayName, 1033),
                            SchemaName = LogicalName,
                            RequiredLevel = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None),
                            IsSecured = false,
                            OptionSet = new OptionSetMetadata()
                            {
                                IsGlobal = IsGlobal,
                                OptionSetType = OptionSetType.Picklist,
                                Name = LogicalName
                            },
                        },
                        EntityName = EntityName
                    };

                    // Execute the request.
                    CreateAttributeResponse messageAttributeResponse = (CreateAttributeResponse)this.Service.Execute(attrReq);
                    return messageAttributeResponse.AttributeId;
                }
            }
            catch (Exception ex)
            {
                ztLogging.Logger.Warn(ex.Message);
            }
            return Guid.Empty;

        }
        public Guid CreateAttributeMultiSelectOptionSet(string EntityName, string LogicalName, string DisplayName)
        {
            try
            {
                if (!DoesFieldExist(EntityName, LogicalName))
                {
                    MultiSelectPicklistAttributeMetadata attrReq = new MultiSelectPicklistAttributeMetadata()
                    {
                        SchemaName = LogicalName,
                        LogicalName = LogicalName,
                        DisplayName = new Label(DisplayName, 1033),
                        RequiredLevel = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None),
                        OptionSet = new OptionSetMetadata()
                        {
                            IsGlobal = false,
                            OptionSetType = OptionSetType.Picklist
                        },
                    };

                    CreateAttributeRequest createAttributeRequest = new CreateAttributeRequest
                    {
                        EntityName = EntityName,
                        Attribute = attrReq
                    };

                    // Execute the request.
                    CreateAttributeResponse messageAttributeResponse = (CreateAttributeResponse)this.Service.Execute(createAttributeRequest);
                    return messageAttributeResponse.AttributeId;
                }
            }
            catch (Exception ex)
            {
                ztLogging.Logger.Warn(ex.Message);
            }
            return Guid.Empty;

        }
        private bool DoesFieldExist(String entityName, String fieldName)
        {
            RetrieveEntityRequest request = new RetrieveEntityRequest
            {
                EntityFilters = Microsoft.Xrm.Sdk.Metadata.EntityFilters.Attributes,
                LogicalName = entityName
            };
            RetrieveEntityResponse response = (RetrieveEntityResponse)this.Service.Execute(request);
            return response.EntityMetadata.Attributes.FirstOrDefault(element => element.LogicalName == fieldName) != null;
        }

        public void CreateAttributeGlobalOptionSet(string EntityName, string LogicalName, string DisplayName)
        {
            if (!GlobalOptionExists(LogicalName))
            {
                OptionSetMetadata setupOptionSetMetadata = new OptionSetMetadata()
                    {
                        Name = LogicalName,
                        DisplayName = new Label(DisplayName, 1033),
                        IsGlobal = true,
                        OptionSetType = OptionSetType.Picklist,

                    };

                // Wrap the OptionSetMetadata in the appropriate request.
                CreateOptionSetRequest createOptionSetRequest = new CreateOptionSetRequest
                    {
                        OptionSet = setupOptionSetMetadata
                    };

                // Pass the execute statement to the CRM service.
                this.Service.Execute(createOptionSetRequest);
            }
        }

        private bool GlobalOptionExists(string logicalName)
        {
            try
            {
                if (!_globalPicklists.Contains(logicalName))
                {
                    RetrieveOptionSetRequest retrieveOptionSetRequest =
                        new RetrieveOptionSetRequest
                            {
                                Name = logicalName
                            };

                    // Execute the request.
                    this.Service.Execute(retrieveOptionSetRequest);
                    _globalPicklists.Add(logicalName);
                    
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public Guid CreateAttributeBoolean(string EntityName, string LogicalName, string DisplayName, string TrueLabel = "Yes", string FalseLabel = "No")
        {
            if (!DoesFieldExist(EntityName, LogicalName))
            {
                CreateAttributeRequest attrReq = new CreateAttributeRequest()
                {
                    Attribute = new BooleanAttributeMetadata()
                    {
                        LogicalName = LogicalName,
                        DisplayName = new Microsoft.Xrm.Sdk.Label(DisplayName, 1033),
                        SchemaName = LogicalName,
                        RequiredLevel = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None),
                        IsSecured = false,
                        OptionSet = new BooleanOptionSetMetadata()
                        {
                            IsGlobal = false,
                            TrueOption = new OptionMetadata(new Microsoft.Xrm.Sdk.Label(TrueLabel, 1033), 1),
                            FalseOption = new OptionMetadata(new Microsoft.Xrm.Sdk.Label(FalseLabel, 1033), 0),

                        }
                    },
                    EntityName = EntityName
                };

                // Execute the request.
                CreateAttributeResponse messageAttributeResponse = (CreateAttributeResponse)this.Service.Execute(attrReq);
                return messageAttributeResponse.AttributeId;

            }
            return Guid.Empty;
        }
        public Guid CreateAttributeLookup(string EntityName, string LogicalName, string DisplayName, string TargetEntityName)
        {
            if (!DoesFieldExist(EntityName, LogicalName))
            {
                CreateOneToManyRequest req = new CreateOneToManyRequest
                {
                    OneToManyRelationship =
                new OneToManyRelationshipMetadata
                {
                    ReferencedEntity = TargetEntityName,
                    ReferencingEntity = EntityName,
                    SchemaName = LogicalName + "_" + EntityName + "_" + TargetEntityName,
                    AssociatedMenuConfiguration = new AssociatedMenuConfiguration
                    {
                        Behavior = AssociatedMenuBehavior.UseLabel,
                        Group = AssociatedMenuGroup.Details,
                        Label = new Microsoft.Xrm.Sdk.Label(DisplayName, 1033),
                        Order = 10000
                    },
                    CascadeConfiguration = new CascadeConfiguration
                    {
                        Assign = CascadeType.NoCascade,
                        Delete = CascadeType.RemoveLink,
                        Merge = CascadeType.NoCascade,
                        Reparent = CascadeType.NoCascade,
                        Share = CascadeType.NoCascade,
                        Unshare = CascadeType.NoCascade
                    }
                },
                    Lookup = new LookupAttributeMetadata
                    {
                        SchemaName = LogicalName,
                        DisplayName = new Microsoft.Xrm.Sdk.Label(DisplayName, 1033),
                        RequiredLevel = new AttributeRequiredLevelManagedProperty(AttributeRequiredLevel.None),
                        Description = new Microsoft.Xrm.Sdk.Label(DisplayName, 1033)
                    }
                };

                CreateOneToManyResponse resp = (CreateOneToManyResponse)this.Service.Execute(req);
                return resp.AttributeId;
            }
            return Guid.Empty;
        }
        public bool PublishEntity(string entityName)
        {            
            Microsoft.Crm.Sdk.Messages.PublishXmlRequest publishRequest = new Microsoft.Crm.Sdk.Messages.PublishXmlRequest();
            publishRequest.ParameterXml ="<importexportxml><entities><entity>" + entityName + "</entity></entities><nodes/><securityroles/><settings/><workflows/></importexportxml>";
            
            try{
                this.Service.Execute(publishRequest);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public string GetDefaultPrefix()
        {
            if (string.IsNullOrEmpty(_defaultPrefix))
            {
                Guid DefaultPublisherId = new Guid("{d21aab71-79e7-11dd-8874-00188b01e34f}");// constant GUID for all default publishers

                Entity DefaultPublisher = (Entity)_serviceProxy.Retrieve(Publisher.EntityLogicalName, DefaultPublisherId, new Microsoft.Xrm.Sdk.Query.ColumnSet(new string[] { "customizationprefix" }));
                _defaultPrefix = (string)DefaultPublisher["customizationprefix"];
            }
            return _defaultPrefix;
        }
    }
}

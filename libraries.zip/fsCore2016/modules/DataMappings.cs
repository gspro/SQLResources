﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Microsoft.Xrm.Sdk;
using System.Globalization;
using ztLogging;

namespace fsCore2016
{
    partial class ztCore2011
    {
        public void MapInt(string ReaderVal, Entity E, string AttributeName)
        {
            try
            {
                    Int32 val;
                    Decimal d;


                    if (Int32.TryParse(ReaderVal, NumberStyles.Any, RuntimeCulture, out val))
                    {
                        E[AttributeName] = val;
                    }
                    else if (Decimal.TryParse(ReaderVal, NumberStyles.Any, RuntimeCulture, out d))
                    {
                        E[AttributeName] = Convert.ToInt32(d);
                    }
                
            }
            catch { }
        }
        public void MapBool(string ReaderVal, Entity E, string AttributeName)
        {
            try
            {
                    string val = ReaderVal.ToLower().Trim();

                    if (val != null && val != "")
                    {
                        E[AttributeName] = (val == "true" || val == "t" || val == "yes" || val == "y" || val == "1") ? true : false;
                    }
            }
            catch { }
        }
        public void MapMoney(string ReaderVal, Entity E, string AttributeName)
        {
            try
            {
                Decimal val;

                if (Decimal.TryParse(ReaderVal, NumberStyles.Any, RuntimeCulture, out val))
                    {
                        E[AttributeName] = new Money(val);
                    }
                
            }
            catch { }
        }
        public void MapString(string ReaderVal,  Entity E, string AttributeName)
        {
            try
            {
                        E[AttributeName] = ReaderVal;
            }
            catch { }
        }
        public void MapDecimal(string ReaderVal, Entity E, string AttributeName)
        {
            try
            {
                Decimal val;
                    
                    if (Decimal.TryParse(ReaderVal, NumberStyles.Any, RuntimeCulture, out val))
                    {
                        E[AttributeName] = val;
                    }
            }
            catch { }
        }
        public void MapDouble(string ReaderVal, Entity E, string AttributeName)
        {
            try
            {
                Double val;

                if (Double.TryParse(ReaderVal, NumberStyles.Any, RuntimeCulture, out val))
                {
                    E[AttributeName] = val;
                }
            }
            catch { }
        }
        public void MapDateTime(string ReaderVal, Entity E, string AttributeName, int TimezoneOffset = 0)
        {
            try
            {
                DateTime val;
                if (DateTime.TryParse(ReaderVal, RuntimeCulture, DateTimeStyles.None, out val))
                    {
                        if (val != new DateTime(1973, 1, 1)) // outlier date for ARISE
                        {
                            val = val.AddHours(TimezoneOffset);
                            E[AttributeName] = val;
                        }
                        else if (val < new DateTime(1900, 1, 1)) // older than CRM's minimum date
                        {
                            // do nothing
                        }
                        else
                        {
                            E[AttributeName] = null;
                        }
                    }
                
            }
            catch { }
        }

        public void MapMultiSelectOptionSet(string ReaderVal, Entity E, string AttributeName, string globalOptionSet, bool AddIfNotFound = false)
        {
            try
            {
                if (ReaderVal == "0") // clear the field
                {
                    E[AttributeName] = null;
                }
                else
                {
                    OptionSetValueCollection OSVC = this.GetMultiSelectOptionSetValueViaCache(E.LogicalName, AttributeName, ReaderVal, globalOptionSet, AddIfNotFound);
                    if (OSVC != null)
                        E[AttributeName] = OSVC;
                }
            }
            catch { }
        }
        public void MapMultiSelectOptionSetInt(string ReaderVal, Entity E, string AttributeName)
        {
            try
            {
                {
                    List<string> optionList = ReaderVal.Trim(';').Split(';').ToList();
                    OptionSetValueCollection options = new OptionSetValueCollection();

                    // loop through values from delimited string
                    foreach (var value in optionList)
                    {
                        options.Add(new OptionSetValue(int.Parse(value)));
                    }

                    E[AttributeName] = options;
                }

            }
            catch { }
        }
        public void MapOptionSet(string ReaderVal, Entity E, string AttributeName, string globalOptionSet, bool AddIfNotFound = false)
        {
            try
            {
                    if (ReaderVal == "0") // clear the field
                    {
                        E[AttributeName] = null;
                    }
                    else
                    {
                        OptionSetValue OSV = this.GetOptionSetValueViaCache(E.LogicalName, AttributeName, ReaderVal, globalOptionSet, AddIfNotFound);
                        if (OSV != null && OSV.Value != int.MinValue)
                        {
                            E[AttributeName] = OSV;
                        }
                    }
            }
            catch { }
        }


        public void MapMultiSelectOptionSet(string ReaderVal, Entity E, string AttributeName, bool AddIfNotFound = false)
        {
            try
            {
                if (ReaderVal == "0") // clear the field
                {
                    E[AttributeName] = null;
                }
                else
                {
                    OptionSetValueCollection OSVC = this.GetMultiSelectOptionSetValueViaCache(E.LogicalName, AttributeName, ReaderVal, AddIfNotFound);
                    if (OSVC != null)
                        E[AttributeName] = OSVC;
                }
            }
            catch { }
        }

        public void MapOptionSetInt(string ReaderVal, Entity E, string AttributeName)
        {
            try
            {
                    {
                        int ValInt = Convert.ToInt32(ReaderVal);
                        OptionSetValue OSV = new OptionSetValue(ValInt);

                        if (OSV != null && OSV.Value != int.MinValue)
                        {
                            E[AttributeName] = OSV;
                        }
                    }
                
            }
            catch { }
        }
        public void MapParty(string ReaderVal, Entity E, string AttributeName, string lookupEntityName, string LookupReferenceAttribute, string Default = null, bool CreateRecordsIfNotFound = false, string DefaultValue = "")
        {
            ActivityParty ap = new ActivityParty();

            
            try
            {
                EntityReference ER = this.GetEntityReferenceByAttribute(lookupEntityName, ReaderVal, LookupReferenceAttribute);

                if (ER != null && ER.Id != null && ER.Id != Guid.Empty)
                {
                    ap.PartyId = ER;
                    E[AttributeName] = ap;
                }
                else if (CreateRecordsIfNotFound && lookupEntityName != "systemuser" && lookupEntityName != "team")
                {
                    try
                    {
                        Entity e = new Entity(lookupEntityName);
                        e[LookupReferenceAttribute] = ReaderVal;
                        Guid recordid = this.Create(e);
                        
                        ap.PartyId = new EntityReference(lookupEntityName, recordid);
                        E[AttributeName] = ap;

                    }
                    catch (Exception ex)
                    {
                        Logger.Warn("WARNING: Could not create a new entity " + lookupEntityName + " as part of a lookup. Value: " + ReaderVal + "." + ex.ToString());
                    }
                }
                else if (DefaultValue != "")
                {
                    ER = this.GetEntityReferenceByAttribute(lookupEntityName, DefaultValue, LookupReferenceAttribute);

                    if (ER != null && ER.Id != null && ER.Id != Guid.Empty)
                    {
                        E[AttributeName] = ER;
                    }
                }
            }
            catch { }
        }
        public void MapPartyList(string ReaderVal, Entity E, string AttributeName, string lookupEntityName, string LookupReferenceAttribute, string Default = null, bool CreateRecordsIfNotFound = false, string DefaultValue = "")
        {
            // Added by Andy P to allow for multiple parties in PartyList

            List<string> emailList = ReaderVal.Split(';').ToList();
            Entity[] aryTo = {  };
            List<Entity> listTo = new List<Entity>();

            foreach (var email in emailList)
            {
                Entity ap = new Entity();
                ap = new Entity("activityparty");

                try
                {
                    EntityReference ER = this.GetEntityReferenceByAttribute(lookupEntityName, email.Trim(), LookupReferenceAttribute);

                    if (ER != null && ER.Id != null && ER.Id != Guid.Empty)
                    {
                        ap["partyid"] = this.GetEntityReferenceByAttribute(lookupEntityName, email.Trim(), LookupReferenceAttribute);
                        //Entity[] aryTo = { ap };
                        listTo.Add(ap);
                        E[AttributeName] = listTo.ToArray();
                    }
                    else if (CreateRecordsIfNotFound && lookupEntityName != "systemuser" && lookupEntityName != "team")
                    {
                        try
                        {
                            Entity e = new Entity(lookupEntityName);
                            e[LookupReferenceAttribute] = email.Trim();
                            Guid recordid = this.Create(e);

                            ap["partyid"] = new EntityReference(lookupEntityName, recordid);
                            //Entity[] aryTo = { ap };
                            listTo.Add(ap);
                            E[AttributeName] = listTo.ToArray(); //aryTo;
                        }
                        catch (Exception ex)
                        {
                            Logger.Warn("WARNING: MapPartyList Could not create a new entity " + lookupEntityName + " as part of a lookup. Value: " + email.Trim() + "." + ex.ToString());
                        }
                    }
                    else if (DefaultValue != "")
                    {
                        ER = this.GetEntityReferenceByAttribute(lookupEntityName, DefaultValue, LookupReferenceAttribute);

                        if (ER != null && ER.Id != null && ER.Id != Guid.Empty)
                        {
                            E[AttributeName] = ER;
                        }
                    }
                }
                catch { }
            }
        }
        public void MapEntityReference(string ReaderVal, Entity E, string AttributeName, string lookupEntityName, string LookupReferenceAttribute, string Default = null, bool CreateRecordsIfNotFound = false, bool SearchCRMIfNotInCache=true)
        {
            Logger.Debug("Mapping entity reference for " + ReaderVal);
            try
            {
                
                if (ReaderVal != string.Empty)
                {
                    EntityReference ER = this.GetEntityReferenceByAttribute(lookupEntityName, ReaderVal, LookupReferenceAttribute, true, SearchCRMIfNotInCache);

                    if (ER != null && ER.Id != null && ER.Id != Guid.Empty)
                    {
                        E[AttributeName] = ER;
                    }
                    else if  (! string.IsNullOrEmpty( Default) )
                    {
                        ER = this.GetEntityReferenceByAttribute(lookupEntityName, Default, LookupReferenceAttribute);
                        Logger.Debug("Lookup default found");

                        if (ER != null && ER.Id != null && ER.Id != Guid.Empty)
                        {
                            E[AttributeName] = ER;
                            if (lookupEntityName.ToLower() == "systemuser") // if this is a systemuser default value
                            {
                                this.EntityCacheAdd(lookupEntityName, LookupReferenceAttribute, ReaderVal, ER.Id); // cache it so we don't lookup again
                            }

                        }
                    }
                    else if (CreateRecordsIfNotFound && lookupEntityName != "systemuser" && lookupEntityName != "team")
                    {
                        try
                        {
                            Entity e = new Entity(lookupEntityName);
                            e[LookupReferenceAttribute] = ReaderVal;
                            Guid recordid = this.Create(e);
                            E[AttributeName] = new EntityReference(lookupEntityName, recordid);

                            this.EntityCacheAdd(lookupEntityName, LookupReferenceAttribute, ReaderVal, recordid); // cache it so we don't lookup again
                        }
                        catch (Exception ex)
                        {
                            Logger.Warn("WARNING: Could not create a new entity '" + lookupEntityName + "' as part of a lookup. Value: '" + ReaderVal + "'." + ex.ToString());
                        }
                    }
                    
                }
            }
            catch { }
        }

        public void MapUniqueIdentifier(string ReaderVal, Entity E, string AttributeName, string lookupEntityName, string LookupReferenceAttribute, EntityReference Default = null)
        {
            try
            {
                Guid g = new Guid(ReaderVal);
                        E[AttributeName] = g;
                   
               
            }
            catch { }

            if (!E.Contains(AttributeName) && Default != null && Default.Id != Guid.Empty) // not found
            {
                E[AttributeName] = Default;
            }
        }
        public void EntityCacheBuild(string ENTITY_NAME, string PRIMARY_KEY, bool PreCacheEntity = true)
        {
            if (!this.EntityCache.ContainsKey(ENTITY_NAME + PRIMARY_KEY) && PreCacheEntity)
            {
                this.PreCacheEntity(ENTITY_NAME, PRIMARY_KEY); // lazy loading cache
            }
        }
        public bool EntityCacheCheck(string ENTITY_NAME, string PRIMARY_KEY, string KeyVal, bool PreCacheEntity = true)
        {
            EntityCacheBuild(ENTITY_NAME, PRIMARY_KEY, PreCacheEntity);

            Guid val = this.GetEntityIDbyAttribute(ENTITY_NAME, KeyVal, PRIMARY_KEY, true); // checks existing cache/queries server if not found
            return val != Guid.Empty;
        }
        public Guid EntityCacheGet(string ENTITY_NAME, string PRIMARY_KEY, string KeyVal)
        {
            return this.GetEntityIDbyAttribute(ENTITY_NAME, KeyVal, PRIMARY_KEY, true); // checks existing cache/queries server if not found
        }
        public bool TryEntityCacheCheck(string ENTITY_NAME, string PRIMARY_KEY, string KeyVal, out Guid EntityId, bool PreCacheEntity = true, bool SearchCRMIfNotInCache = true)
        {
            EntityCacheBuild(ENTITY_NAME, PRIMARY_KEY, PreCacheEntity);

            EntityId = this.GetEntityIDbyAttribute(ENTITY_NAME, KeyVal, PRIMARY_KEY, true, SearchCRMIfNotInCache); // checks existing cache/queries server if not found
            return EntityId != Guid.Empty;
        }

    }
}


﻿using System;
using System.Configuration;
using System.Diagnostics;
using log4net;
using log4net.Config;
using System.ServiceModel;
using System.Reflection;

namespace ztLogging
{
    public static class Logger
    {
        private static ILog _instance;
        private static ILog Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (typeof(Logger))
                    {
                        if (_instance == null)
                        {

                            _instance = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
                            XmlConfigurator.Configure();
                        }
                    }
                }

                return _instance;
            }
        }

        #region Debug Logging

        public static void DebugFormat(string message, params object[] args)
        {
            if (Logger.Instance.IsDebugEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(message, args);
                Logger.Instance.Debug(loggingMessage);
            }
        }
        public static void DebugFormat(Exception exception, string message, params object[] args)
        {
            if (Logger.Instance.IsDebugEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(message, args);
                Logger.Instance.Debug(loggingMessage, exception);
            }
        }
        public static void DebugMethodName()
        {
            if (Logger.Instance.IsDebugEnabled)
            {
                MethodBase methodBase = new StackTrace().GetFrame(1).GetMethod();
                string methodName = string.Format("{0}.{1}{2}", methodBase.DeclaringType.FullName, methodBase.Name, Environment.NewLine);
                Logger.Instance.Debug(methodName);
            }
        }
        public static void DebugParameter(string parameterName, object value)
        {
            if (value == null)
            {
                DebugFormat("{0} - null", parameterName);
            }
            else if (value.GetType().IsSerializable && !(value.GetType().Equals(typeof(string))) && !(value.GetType().Equals(typeof(Guid))))
            {
                DebugFormat("{0}:", parameterName);
                Debug(value);
            }
            else
            {
                DebugFormat("{0}: {1}", parameterName, value);
            }
        }
        public static void Debug(object message)
        {
            Debug(new object[] { message });
        }
        public static void Debug(Exception exception, object message)
        {
            Debug(exception, new object[] { message });
        }
        public static void Debug(object[] messages)
        {
            if (Logger.Instance.IsDebugEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(messages);
                Logger.Instance.Debug(loggingMessage);
            }
        }
        public static void Debug(Exception exception, object[] messages)
        {
            if (Logger.Instance.IsDebugEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(messages);
                if (exception is FaultException)
                {
                    loggingMessage += exception.ToString() + exception.StackTrace + Environment.NewLine;
                }
                Logger.Instance.Debug(loggingMessage, exception);
            }
        }

        #endregion

        #region Info Logging

        public static void InfoFormat(string message, params object[] args)
        {
            if (Logger.Instance.IsInfoEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(message, args);
                Logger.Instance.Info(loggingMessage);
            }
        }
        public static void InfoFormat(Exception exception, string message, params object[] args)
        {
            if (Logger.Instance.IsInfoEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(message, args);
                Logger.Instance.Info(loggingMessage, exception);
            }
        }
        public static void Info(object message)
        {
            Info(new object[] { message });
        }
        public static void Info(Exception exception, object message)
        {
            Info(exception, new object[] { message });
        }
        public static void Info(object[] messages)
        {
            if (Logger.Instance.IsInfoEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(messages);
                Logger.Instance.Info(loggingMessage);
            }
        }
        public static void Info(Exception exception, object[] messages)
        {
            if (Logger.Instance.IsInfoEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(messages);
                if (exception is FaultException)
                {
                    loggingMessage += exception.ToString() + exception.StackTrace + Environment.NewLine;
                }
                Logger.Instance.Info(messages, exception);
            }
        }

        #endregion

        #region Warn Logging

        public static void WarnFormat(string message, params object[] args)
        {
            if (Logger.Instance.IsWarnEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(message, args);
                Logger.Instance.Warn(loggingMessage);
            }
        }
        public static void WarnFormat(Exception exception, string message, params object[] args)
        {
            if (Logger.Instance.IsWarnEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(message, args);
                Logger.Instance.Warn(loggingMessage, exception);
            }
        }
        public static void Warn(object message)
        {
            Warn(new object[] { message });
        }
        public static void Warn(Exception exception, object message)
        {
            Warn(exception, new object[] { message });
        }
        public static void Warn(object[] messages)
        {
            if (Logger.Instance.IsWarnEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(messages);
                Logger.Instance.Warn(loggingMessage);
            }
        }
        public static void Warn(Exception exception, object[] messages)
        {
            if (Logger.Instance.IsWarnEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(messages);
                if (exception is FaultException)
                {
                    loggingMessage += exception.ToString() + exception.StackTrace + Environment.NewLine;
                }
                Logger.Instance.Warn(loggingMessage, exception);
            }
        }

        #endregion

        #region Error Logging

        //public static void Error(Func<string> message, Exception ex)
        //{
        //    if (Debug)
        //    {
        //        string message1 = message.Invoke();
        //    }
        //}

        public static void ErrorFormat(string message, params object[] args)
        {
            if (Logger.Instance.IsErrorEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(message, args);
                Logger.Instance.Error(loggingMessage);
            }
        }
        public static void ErrorFormat(Exception exception, string message, params object[] args)
        {
            if (Logger.Instance.IsErrorEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(message, args);
                Logger.Instance.Error(loggingMessage, exception);
            }
        }
        public static void Error(object message)
        {
            Error(new object[] { message });
        }
        public static void Error(Exception exception, object message)
        {
            Error(exception, new object[] { message });
        }
        public static void Error(object[] messages)
        {
            if (Logger.Instance.IsErrorEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(messages);
                Logger.Instance.Error(loggingMessage);
            }
        }
        public static void Error(Exception exception, object[] messages)
        {
            if (Logger.Instance.IsErrorEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(messages);
                if (exception is FaultException)
                {
                    loggingMessage += exception.ToString() + exception.StackTrace + Environment.NewLine;
                }
                Logger.Instance.Error(loggingMessage, exception);
            }
        }

        #endregion

        #region Fatal Logging

        public static void FatalFormat(string message, params object[] args)
        {
            if (Logger.Instance.IsFatalEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(message, args);
                Logger.Instance.Fatal(loggingMessage);
            }
        }
        public static void FatalFormat(Exception exception, string message, params object[] args)
        {
            if (Logger.Instance.IsFatalEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(message, args);
                Logger.Instance.Fatal(loggingMessage, exception);
            }
        }
        public static void Fatal(object message)
        {
            Fatal(new object[] { message });
        }
        public static void Fatal(Exception exception, object message)
        {
            Fatal(exception, new object[] { message });
        }
        public static void Fatal(object[] messages)
        {
            if (Logger.Instance.IsFatalEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(messages);
                Logger.Instance.Fatal(loggingMessage);
            }
        }
        public static void Fatal(Exception exception, object[] messages)
        {
            if (Logger.Instance.IsFatalEnabled)
            {
                string loggingMessage = MessageFormatter.FormatLogMessage(messages);
                if (exception is FaultException)
                {
                    loggingMessage += exception.ToString() + exception.StackTrace + Environment.NewLine;
                }
                Logger.Instance.Fatal(loggingMessage, exception);
            }
        }

        #endregion
    }
}

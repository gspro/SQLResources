﻿using System;
using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace ztLogging
{
    /// <summary>
    /// This class formats the messages and exceptions to create human readable error message
    /// </summary>
    public static class MessageFormatter
    {
        #region Public Methods

        public static string FormatLogMessage(string format, params object[] args)
        {
            StringBuilder logMessage = new StringBuilder(1024);
            logMessage.AppendLine(string.Format(format, args));
            return logMessage.ToString();
        }

        /// <summary>
        /// This method creates human readable message by extracting details from Request and Response of WebService.
        /// </summary>
        /// <param name="messages">object array contains Request and Response of WebService.</param>
        /// <returns>string object containing formatted logging message.</returns>
        public static string FormatLogMessage(object[] messages)
        {
            StringBuilder logMessage = new StringBuilder(1024);
            StringWriter writer = new StringWriter(logMessage);
            try
            {
                if (messages != null)
                {
                    foreach (object message in messages)
                    {
                        if (message != null)
                        {
                            // If message is exception then format that exception.
                            if (message is Exception)
                            {
                                logMessage.Append(FormatExceptionMessage((Exception)message) + Environment.NewLine);
                            }
                            // If message is serializable, not a string and not a Guid then serialize it.
                            else if (message.GetType().IsSerializable
                                && !(message.GetType().Equals(typeof(string)))
                                && !(message.GetType().Equals(typeof(Guid)))
                                && !(message.GetType().IsEnum))
                            {
                                XmlSerializer serializer = new XmlSerializer(message.GetType());
                                logMessage.Append(Environment.NewLine);
                                serializer.Serialize(writer, message);
                                logMessage.Append(Environment.NewLine);
                            }
                            else
                            {
                                logMessage.Append(message.ToString() + Environment.NewLine);
                            }
                        }
                    }
                }
            }
            catch
            {
                // Suppressing any exception while extracting information from message.
            }

            return logMessage.ToString();
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// This method creates a human-readable error message by extracting details from an exception depending on the type
        /// </summary>
        /// <param name="exception">The exception which has to be used as source of error message</param>
        /// <returns>string object containing formatted message</returns>
        private static string FormatExceptionMessage(Exception exception)
        {
            StringBuilder formattedMessage = new StringBuilder(1024);


            if (exception is System.Web.Services.Protocols.SoapException)
            {
                formattedMessage.Append(PrivateFormatSoapExceptionMessage((System.Web.Services.Protocols.SoapException)exception));
            }
            else if (exception is System.Data.SqlClient.SqlException)
            {
                formattedMessage.Append(PrivateFormatSqlExceptionMessage((System.Data.SqlClient.SqlException)exception));
            }
            else if (exception is ArgumentException)
            {
                formattedMessage.Append(PrivateFormatArgumentExceptionMessage((ArgumentException)exception));
            }
            else
            {
                formattedMessage.Append(exception.ToString());
            }

            //if there is an inner exception add it to the formatted exception list.
            if (exception.InnerException != null)
            {
                formattedMessage.Append(FormatExceptionMessage(exception.InnerException));
            }

            return formattedMessage.ToString();
        }

        /// <summary>
        /// This method creates a human-readable error message by extracting details from soap exception
        /// </summary>
        /// <param name="soapE">The exception which has to be used as source of error message</param>
        /// <returns>string object containing error log message</returns>
        private static string PrivateFormatSoapExceptionMessage(System.Web.Services.Protocols.SoapException soapE)
        {
            StringBuilder errorLogMessage = new StringBuilder(1024);

            try
            {
                if (soapE == null)
                {
                    return errorLogMessage.ToString();
                }

                errorLogMessage.Append(Environment.NewLine);
                errorLogMessage.Append("Code: " + soapE.Code.ToString() + Environment.NewLine);
                errorLogMessage.Append("Actor: " + soapE.Actor + Environment.NewLine);

                if (soapE.Detail != null)
                {
                    if (soapE.Detail.InnerXml != null)
                    {
                        errorLogMessage.Append("Detail: " + soapE.Detail.InnerXml.ToString() + Environment.NewLine);
                    }
                }

                if (soapE.Message != null)
                {
                    errorLogMessage.Append("Message: " + soapE.Message.ToString() + Environment.NewLine);
                }
            }
            catch
            {
                //Suppressing any exception while extracting information from soap message.
            }

            return errorLogMessage.ToString();
        }

        /// <summary>
        /// This method creates a human-readable error message by extracting details from argument exception
        /// </summary>
        /// <param name="argE">The exception which has to be used as source of error message</param>
        /// <returns>string object containing error log message</returns>
        private static string PrivateFormatArgumentExceptionMessage(ArgumentException argE)
        {
            StringBuilder errorLogMessage = new StringBuilder(1024);

            try
            {
                if (argE == null)
                {
                    return errorLogMessage.ToString();
                }

                errorLogMessage.Append(Environment.NewLine);

                #region Create message with important information extracted from Argument Exception

                errorLogMessage.Append("Argument Error encountered. Details:");
                errorLogMessage.Append(Environment.NewLine);
                errorLogMessage.Append("ParamName: " + ((argE.ParamName != null) ? argE.ParamName.ToString() : string.Empty));

                #endregion

            }
            catch
            {
                //Suppressing any exception while extracting information from exception.
            }

            return errorLogMessage.ToString();
        }

        /// <summary>
        /// This method creates a human-readable error message by extracting details from sql exception
        /// </summary>
        /// <param name="sqlE">The exception which has to be used as source of error message</param>
        /// <returns>string object containing error log message</returns>
        private static string PrivateFormatSqlExceptionMessage(System.Data.SqlClient.SqlException sqlE)
        {
            StringBuilder errorLogMessage = new StringBuilder(1024);

            try
            {
                if (sqlE == null)
                {
                    return errorLogMessage.ToString();
                }

                errorLogMessage.Append(Environment.NewLine);

                #region Create message with important information extracted from SQL Exception

                errorLogMessage.Append("SQL Error encountered. Details:");
                errorLogMessage.Append(Environment.NewLine);
                errorLogMessage.Append("Class: " + sqlE.Class.ToString());
                errorLogMessage.Append(Environment.NewLine);
                errorLogMessage.Append("LineNumber: " + sqlE.LineNumber.ToString());
                errorLogMessage.Append(Environment.NewLine);
                errorLogMessage.Append("Number: " + sqlE.Number.ToString());
                errorLogMessage.Append(Environment.NewLine);
                errorLogMessage.Append("Procedure: " + ((sqlE.Procedure != null) ? sqlE.Procedure.ToString() : string.Empty));
                errorLogMessage.Append(Environment.NewLine);
                errorLogMessage.Append("Server: " + ((sqlE.Server != null) ? sqlE.Server.ToString() : string.Empty));
                errorLogMessage.Append(Environment.NewLine);
                errorLogMessage.Append("Source: " + ((sqlE.Source != null) ? sqlE.Source.ToString() : string.Empty));
                errorLogMessage.Append(Environment.NewLine);
                errorLogMessage.Append("State: " + sqlE.State.ToString());

                #endregion

            }
            catch
            {
                //Suppressing any exception while extracting information from exception.
            }

            return errorLogMessage.ToString();
        }

        #endregion
    }
}
